import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, from } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { BehaviorSubject } from "rxjs";
import { Globals } from '../global';
import {} from '../myfunction.service';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  private readonly Users: string;
  
  userIdSource = new  BehaviorSubject<number>(0);
  userIdData: any;

  constructor(private http: HttpClient, private Globals: Globals) { 
    this.Users = Globals.baseUrl;
    this.userIdData= this.userIdSource.asObservable();
  }

  Login(UserData: any){
  
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Users + "Login", UserData, { headers: header })
  }
  
}