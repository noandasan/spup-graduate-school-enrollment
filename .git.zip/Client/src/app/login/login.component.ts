import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { LoginService } from '../login/login.service';
import { AuthService } from '../auth.service';
import { myfunction } from '../myfunction.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login: FormGroup;
  submitted = false;
  Error=false;
  InvalidLogin=false;

  constructor(
    private builder: FormBuilder,
    private LoginService: LoginService,
    private AuthService: AuthService,
    private myfunction: myfunction
  ) { }

  ngOnInit() {
    this.login = this.builder.group({
      email: new FormControl('n_oandasan@yahoo.com', [Validators.required, Validators.email]),
      password: new FormControl('1111', [Validators.required])   
    });
  }
  get f() { return this.login.controls; }
  onFocus(){
    this.InvalidLogin=false;
  }

  onLogin() {
   
    this.submitted = true;
    let UserData = {
      'email': this.login.get('email').value,
      'password': this.login.get('password').value,
    };

    this.LoginService.Login(UserData).subscribe(data => {
      if (data['error']==true){
        this.InvalidLogin=data['error'];
        
      }else{
        this.AuthService.login(data['token']);
      }
    });
  }
}
