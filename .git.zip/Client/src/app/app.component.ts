import { Component, OnInit } from '@angular/core';
import { LayoutService,LayoutStore} from 'angular-admin-lte';

import { Menu } from './Model';
import { MenuService } from './menu.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent implements OnInit {
  public customLayout: boolean;
  MainMenus: Menu[];
  policies:[]=[];
  

  constructor(
    private layoutService: LayoutService,
    private layoutStore: LayoutStore,
    private MainMenuService: MenuService
  ) {}

  ngOnInit() {
    this.layoutService.isCustomLayout.subscribe((value: boolean) => {
      this.customLayout = value;
    });

    this.getMenu();
  }

  getMenu() {
    return this.MainMenuService.getMenu()
      .subscribe(
        MainMenu => {
          this.layoutStore.setSidebarLeftMenu(MainMenu);
          this.MainMenus = MainMenu
        
      }
   );
 }
}
