import { Component, OnInit } from '@angular/core';
import { Globals } from 'src/app/global';
import { ProfileService } from 'src/app/+profile/profile.service';
import { Router } from '@angular/router';
import decode from 'jwt-decode';
@Component({
  selector: 'app-header-inner',
  templateUrl: './header-inner.component.html'
})
export class HeaderInnerComponent implements OnInit  {
  
  userId:number;
  picture:string;
  ProfilePic:string;
  firstname: string;
  lastname: string;
  position: string;

  constructor(
    private router: Router,
    private globals: Globals,
    private ProfileService: ProfileService
  ) {

    const userId=decode(localStorage.getItem("token"));
    this.ProfileService.changeUserId(userId['id']);
    this.userId=userId['id'];

    this.ProfileService.MyProfile(this.userId).subscribe(data => {
      
      this.picture=data['User'].profile;
      this.firstname=data['User'].firstname;
      this.lastname=data['User'].lastname;
      this.position=data['User'].position;
       this.loadprofile();
    });
    
  }
  ngOnInit() {
  }
  logout(){
      localStorage.clear();
      window.location.href="/login"; 
  }
  loadprofile(){
    if(this.picture){
      this.ProfilePic=this.globals.basedUrlProfile+''+this.picture;
    }else{
      this.ProfilePic=this.globals.basedUrlProfile+'default.jpg';
    }
}
}
