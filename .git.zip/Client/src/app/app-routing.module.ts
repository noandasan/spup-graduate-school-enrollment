import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { MainComponent } from './main/main.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './guards/auth-guard.service';
import { ProfileComponent } from './+profile/profile.component';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent,
    data: {
        title: 'Login',
        customLayout: true
    },
  },
  {
  path: '',
  canActivate: [AuthGuard],
  data: {
      title: 'Dashboard'
   },
   children: [
        {
          path: '',
          component: HomeComponent
        }, {
          path: 'administrator',
          data: {
            title: 'Administrator'
          },
          children: [
            {
              path: 'users',
              loadChildren: './+users/users.module#UsersModule',
              data: {
                title: 'Users',
                customLayout: false
              }
            },
            {
              path: 'prefixes',
              loadChildren: './+prefix/prefix.module#PrefixModule',
              data: {
                title: 'Prefixes',
                customLayout: false
              }
            }
          ]
        },
        {
          path: 'profile',
          loadChildren: './+profile/profile.module#ProfileModule',
          data: {
            title: 'Profile',
            customLayout: false
         }
        },
        {
          path:'rm',
          data: {
            title: 'Record Master'
          },
          children:[
            {
              path: 'sy',
              loadChildren: './recordmaster/+schoolyear/sy.module#SYModule',
                data: {
                  title: 'School Year',
                  customLayout: false
              }
            },
            {
              path: 'courses',
              loadChildren: './recordmaster/+courses/courses.module#CoursesModule',
                data: {
                  title: 'Courses',
                  customLayout: false
              }
            },
            {
              path: 'specializations',
              loadChildren: './recordmaster/+specialization/specializations.module#SpecializationsModule',
                data: {
                  title: 'Specializations',
                  customLayout: false
              }
            },
            {
              path: 'semesters',
              loadChildren: './recordmaster/+semesters/semesters.module#SemestersModule',
                data: {
                  title: 'Semesters',
                  customLayout: false
              }
            },
            {
              path: 'subjects',
              loadChildren: './recordmaster/+subjects/subjects.module#SubjectsModule',
                data: {
                  title: 'Subjects',
                  customLayout: false
              }
            },
            {
              path: 'levels',
              loadChildren: './recordmaster/+levels/levels.module#LevelsModule',
                data: {
                  title: 'Levels',
                  customLayout: false
              }
            }
          ]
        },{
          path:'students',
          data: {
            title: 'Students'
          },
            children: [
              {
                path: 'information',
                loadChildren: './students/+information/informations.module#InformationsModule',
              } 
            ]
        },{
          path:'enrollment',
          loadChildren: './enrollment/enrollment.module#EnrollmentModule',
          data: {
            title: 'Enrollment'
          },
          canActivate: [AuthGuard]          
        }
      ]
    }

];

// const routes: Routes = [
//   {
//   path: '',
//   data: {
//       title: 'Get Started'
//   },
//   children: [
//     {
//       path: '',
//       component: HomeComponent
//     }, {
//       path: 'accordion',
//       loadChildren: './+accordion/accordion.module#AccordionModule',
//       data: {
//         title: 'Accordion'
//       }
//     }, {
//       path: 'alert',
//       loadChildren: './+alert/alert.module#AlertModule',
//       data: {
//         title: 'Alert',
//       }
//     }, {
//       path: 'layout',
//       data: {
//         title: 'Layout',
//       },
//       children: [
//         {
//           path: 'configuration',
//           loadChildren: './+layout/configuration/configuration.module#ConfigurationModule',
//           data: {
//             title: 'Configuration'
//           }
//         }, {
//           path: 'custom',
//           loadChildren: './+layout/custom/custom.module#CustomModule',
//           data: {
//             title: 'Disable Layout'
//             // disableLayout: true
//           }
//         }, {
//           path: 'content',
//           loadChildren: './+layout/content/content.module#ContentModule',
//           data: {
//             title: 'Content'
//           }
//         }, {
//           path: 'header',
//           loadChildren: './+layout/header/header.module#HeaderModule',
//           data: {
//             title: 'Header'
//           }
//         }, {
//           path: 'sidebar-left',
//           loadChildren: './+layout/sidebar-left/sidebar-left.module#SidebarLeftModule',
//           data: {
//             title: 'Sidebar Left'
//           }
//         }, {
//           path: 'sidebar-right',
//           loadChildren: './+layout/sidebar-right/sidebar-right.module#SidebarRightModule',
//           data: {
//             title: 'Sidebar Right'
//           }
//         },
//       ]
//     }, {
//       path: 'boxs',
//       data: {
//         title: 'Boxs',
//       },
//       children: [
//         {
//           path: 'box',
//           loadChildren: './+boxs/box-default/box-default.module#BoxDefaultModule',
//           data: {
//             title: 'Box'
//           }
//         }, {
//           path: 'info-box',
//           loadChildren: './+boxs/box-info/box-info.module#BoxInfoModule',
//           data: {
//             title: 'Info Box'
//           }
//         }, {
//           path: 'small-box',
//           loadChildren: './+boxs/box-small/box-small.module#BoxSmallModule',
//           data: {
//             title: 'Small Box'
//           }
//         }
//       ]}, {
//         path: 'dropdown',
//         loadChildren: './+dropdown/dropdown.module#DropdownModule',
//         data: {
//           title: 'Dropdown',
//         }
//       }, {
//         path: 'tabs',
//         loadChildren: './+tabs/tabs.module#TabsModule',
//         data: {
//           title: 'Tabs',
//         }
//       }
//     ]
//   }, {
//     path: 'form',
//     data: {
//       title: 'Form',
//     },
//     children: [
//       {
//         path: 'input-text',
//         loadChildren: './+form/input-text/input-text.module#InputTextModule',
//         data: {
//           title: 'Input Text',
//         }
//       }
//     ]
//   }, {
//     path: 'login',
//     loadChildren: './+login/login.module#LoginModule',
//     data: {
//       customLayout: true
//     }
//   }, {
//     path: 'register',
//     loadChildren: './+register/register.module#RegisterModule',
//     data: {
//       customLayout: true
//     }
//   },
// ];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const RoutingComponent=[
  HomeComponent,
  MainComponent,
  LoginComponent,
  DashboardComponent

] ;