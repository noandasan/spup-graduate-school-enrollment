import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { adminLteConf } from './admin-lte.conf';

import { AppRoutingModule, RoutingComponent } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CoreModule } from './core/core.module';

import { LayoutModule } from 'angular-admin-lte';

import { AppComponent } from './app.component';

import { LoadingPageModule, MaterialBarModule } from 'angular-loading-page';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthGuard } from './guards/auth-guard.service';
import { RoleGuard } from './guards/role-guard.service';
import { Globals } from './global';




@NgModule({
  imports: [
    BrowserModule,
    AppRoutingModule,
    CoreModule,
        LoadingPageModule, MaterialBarModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    LayoutModule.forRoot(adminLteConf)
  ],
  declarations: [
    AppComponent,
    RoutingComponent
  

  ],
  bootstrap: [AppComponent],
  providers: [AuthGuard, RoleGuard, Globals]
})
export class AppModule {}
