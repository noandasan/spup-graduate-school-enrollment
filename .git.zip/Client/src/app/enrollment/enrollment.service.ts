import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, from } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { BehaviorSubject } from "rxjs";
import { Globals } from '../global';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class EnrollmentService {
  private readonly Enrollment: string;
  
  EnrollmentIdSource = new  BehaviorSubject<number>(0);
  EnrollmentIdData: any;

  constructor(private http: HttpClient, private Globals: Globals) { 
    this.Enrollment = Globals.baseUrl;
    this.EnrollmentIdData= this.EnrollmentIdSource.asObservable();
  }

  getEnrollmentList() {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Enrollment + "getEnrollment", { headers: header })
  }

  getSubjectOffer(enrollData: any){
  let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Enrollment + "getSubjectOffer",enrollData, { headers: header })
}

  addNewEnrollment(EnrollmentData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Enrollment + "addNewEnrollment", EnrollmentData, { headers: header })
  }
  
  searchEnrollment(EnrollmentData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Enrollment + "SearchEnrollment", EnrollmentData, { headers: header })
  }


  EnrollmentCourse(courseid: number){
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Enrollment + "EnrollmentCourse/courseid/"+ courseid, { headers: header })
  }

  EnrollmentSubject(EnrollmentData: any){
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Enrollment + "EnrollmentSubject", EnrollmentData, { headers: header })
  }

  EnrollmentSubjectAvialable(EnrollmentData: any){
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Enrollment + "EnrollmentSubjectAvialable", EnrollmentData, { headers: header })
  }




  getEnrollmentId(enrollmentid: number) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Enrollment + "getEnrollmentId/enrollmentid/" + enrollmentid, { headers: header })
  }
  changeEnrollmentId(enrollmentid: number) {
    this.EnrollmentIdSource.next(enrollmentid);
  }
  UpdateEnrollment(enrollmentid: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Enrollment + "UpdateEnrollment", enrollmentid, { headers: header })
  }
//   DeleteLevels(LevelsId: number){
   
//     let header = new HttpHeaders();
//     header.append('Content-Type', 'applications/json');
//     return this.http.get(this.Levels + "DeleteLevels/LevelsId/" +LevelsId, { headers: header})
// }

EnrollSubject(id: number, enrolled: number, courseid: number,levelid: number,schoolyearid: number,semesterid: number,specializationid: number,studentid: any) {
  let header = new HttpHeaders();
  header.append('Content-Type', 'applications/json');
  return this.http.post(this.Enrollment + "EnrollSubject/id/"+ id+"/enrolled/"+ enrolled+"/courseid/"+courseid+"/levelid/"+levelid+"/schoolyearid/"+schoolyearid+"/semesterid/"+semesterid+"/specializationid/"+specializationid+"/studentid/"+studentid, { headers: header })
}
  
 handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}