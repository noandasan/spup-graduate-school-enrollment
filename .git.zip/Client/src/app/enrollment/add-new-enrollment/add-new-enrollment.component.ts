import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';

import { EnrollmentService } from '../enrollment.service';
import { SubjectsService } from 'src/app/recordmaster/+subjects/subjects.service';
import { SemestersService } from 'src/app/recordmaster/+semesters/semesters.service';
import { InformationsService } from 'src/app/students/+information/informations.service';
import { SYService } from 'src/app/recordmaster/+schoolyear/sy.service';
import { LevelsService } from 'src/app/recordmaster/+levels/levels.service';
import { CoursesService } from 'src/app/recordmaster/+courses/courses.service';
import { SpecializationsService } from 'src/app/recordmaster/+specialization/specializations.service';

@Component({
  selector: 'app-add-new-enrollment',
  templateUrl: './add-new-enrollment.component.html',
  styleUrls: ['./add-new-enrollment.component.css']
})
export class AddNewEnrollmentComponent implements OnInit {

  addNewEnrollment: FormGroup;
  event: EventEmitter<any> = new EventEmitter();
  submitted = false;
  loading: boolean;

  InformationList: any[] = [];
  SchoolYearList: any[] = [];
  LevelList: any[] = [];
  SemestersList: any[]=[];
  CoursesList: any[]=[];
  SpecializationsList: any[]=[];

  OfferedList: any[] = [];
 
  constructor(
    private builder: FormBuilder,
    private EnrollmentService: EnrollmentService,
    private bsModalRef: BsModalRef, 
    public toastr: ToastrManager,
    private InformationsService: InformationsService,
    private SYService: SYService,
    private LevelsService: LevelsService,
    private SemestersService: SemestersService,
    private CoursesService: CoursesService,
  ) {

      this.InformationsService.getInformationsList().subscribe(data => {
        Object.assign(this.InformationList, data);
      }, error => {
        console.log("Error while Student Information ", error);
      });

      this.SYService.getSYList1().subscribe(data => {
        Object.assign(this.SchoolYearList, data);
      }, error => {
        console.log("Error while getting School Year ", error);
      });

      this.LevelsService.getLevelsList().subscribe(data => {
        Object.assign(this.LevelList, data);
      }, error => {
        console.log("Error while getting Level ", error);
      });

      this.SemestersService.getSemestersList1().subscribe(data => {
        Object.assign(this.SemestersList, data);
      }, error => {
        console.log("Error while getting Semester ", error);
      });

      this.CoursesService.getCoursesList().subscribe(data => {
        Object.assign(this.CoursesList, data);
      }, error => {
        console.log("Error while getting courses ", error);
      });
   }

   LoadingSpecialization(){
    this.EnrollmentService.EnrollmentCourse(this.addNewEnrollment.get('courseid').value).subscribe(data=>{
      Object.assign(this.SpecializationsList, data);
    })
   }

   get f() { return this.addNewEnrollment.controls; }


  //  SearchSubject(){
  //   this.submitted = true;

  //   let EnrollmentData = {
  //     'studentid': this.addNewEnrollment.get('studentid').value,
  //     'schoolyearid': this.addNewEnrollment.get('schoolyearid').value,
  //     'levelid': this.addNewEnrollment.get('levelid').value,
  //     'semesterid': this.addNewEnrollment.get('semesterid').value,
  //     'courseid': this.addNewEnrollment.get('courseid').value,
  //     'specializationid': this.addNewEnrollment.get('specializationid').value
  //   };
  //   if (this.addNewEnrollment.invalid) {
  //     return;
  //   }
  //   this.EnrollmentService.EnrollmentSubject(EnrollmentData).subscribe(data=>{
  //     Object.assign(this.OfferedList, data);
  //     console.log(this.OfferedList);
  //     if (data['error']==true){
  //       this.toastr.errorToastr('Enrollment already exist.', '', {
  //         position: 'top-right',
  //         animate: 'slideFromTop',
  //       });
  //       this.loading=false;
  //       return;
  //     }else{
  //       this.loading=false;
  //       this.event.emit('OK');
  //       this.bsModalRef.hide();
  //       this.toastr.successToastr('Course Saved.', '', {
  //         position: 'top-right',
  //         animate: 'slideFromTop',
  //       });
  //     }
  //   })


    
  //  }

    ngOnInit() {
      this.addNewEnrollment = this.builder.group({
        studentid: new FormControl('', [Validators.required]),
        schoolyearid: new FormControl('', [Validators.required]),
        levelid: new FormControl('', [Validators.required]),
        semesterid: new FormControl('', [Validators.required]),
        courseid: new FormControl('', [Validators.required]),
        specializationid: new FormControl('', [Validators.required]),
      });
    }
    onClose() {
      this.bsModalRef.hide();
    }
    
    onSubmit(){
      this.submitted = true;
      let EnrollmentData = {
        'studentid': this.addNewEnrollment.get('studentid').value,
        'schoolyearid': this.addNewEnrollment.get('schoolyearid').value,
        'levelid': this.addNewEnrollment.get('levelid').value,
        'semesterid': this.addNewEnrollment.get('semesterid').value,
        'courseid': this.addNewEnrollment.get('courseid').value,
        'specializationid': this.addNewEnrollment.get('specializationid').value
      };

      if (this.addNewEnrollment.invalid) {
        return;
      }

      this.loading=true;
      this.EnrollmentService.addNewEnrollment(EnrollmentData).subscribe(data=>{
         this.EnrollmentService.EnrollmentSubject(EnrollmentData).subscribe()

        if (data['error']==true){
          this.toastr.errorToastr('Student already enrolled.', '', {
            position: 'top-right',
            animate: 'slideFromTop',
          });
          this.loading=false;
          return;
        }else{
          this.toastr.successToastr('Student successfully enrolled.', '', {
            position: 'top-right',
            animate: 'slideFromTop',
          });
          this.loading=false;
          this.event.emit('OK');
          this.bsModalRef.hide();
        }
        
      });

    }
  }


