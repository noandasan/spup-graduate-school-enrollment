import { Component, OnInit, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';


import { EnrollmentService } from './enrollment.service';
import { AddNewEnrollmentComponent } from './add-new-enrollment/add-new-enrollment.component';
import { AddNewEnrollmentSubjectComponent } from './add-new-enrollment-subject/add-new-enrollment-subject.component';
import { EditEnrollmentComponent } from './edit-enrollment/edit-enrollment.component';
// import { EditLevelsComponent } from './edit-levels/edit-levels.component';
//  import { DeleteLevelsComponent } from './delete-levels/delete-levels.component';

@Component({
  selector: 'app-enrollment',
  templateUrl: './enrollment.component.html',
  styleUrls: ['./enrollment.component.css']
})
export class EnrollmentComponent implements OnInit {
  bsModalRef: BsModalRef;
  bsModalRefSubject: BsModalRef;
  SearchForm: FormGroup;
  submitted = false;
  Enrollmentlist: any[] = [];
  event: EventEmitter<any> = new EventEmitter();

  myDateValue: Date;
  show_normal: boolean;
  show_date: boolean;
  valid: boolean;
  TotalRec: number;
  state: number;

  config = {
    itemsPerPage: 0,
    currentPage: 0,
    totalItems:0
  };

  public maxSize: number = 20;
  public directionLinks: boolean = true;
  public autoHide: boolean = false;
  public responsive: boolean = true;
  public labels: any = {
    previousLabel: '',
    nextLabel: '',
    screenReaderPaginationLabel: 'Pagination',
    screenReaderPageLabel: 'page',
    screenReaderCurrentLabel: `You're on page`
  };

  constructor(
    private builder: FormBuilder, 
    private bsModalService: BsModalService,
    private EnrollmentService: EnrollmentService
  ){ 

    this.getEnrollment();

    this.config = {
      itemsPerPage: 20,
      currentPage: 1,
      totalItems: this.TotalRec
    };
    this.show_normal = true;
    this.valid = false;
    this.show_date = false;

  }

  ngOnInit() {
    this.SearchForm = this.builder.group({
      searchkey: new FormControl('', []),
      fileterdate: new FormControl('', [Validators.required])
    });
    this.myDateValue = new Date();
  }


  get f() { return this.SearchForm.controls; }

  SearchfieldSet(val) {
    document.getElementById('searchfield').innerHTML = val + ' <span class="fa fa-caret-down"></span>';
    if (val.toLowerCase() === 'created') {
      this.show_normal = false;
      this.show_date = true;
      this.SearchForm.controls['fileterdate'].updateValueAndValidity();
    } else {
      this.show_normal = true;
      this.show_date = false;
      this.SearchForm.controls['fileterdate'].setErrors(null);
    }

  }

  onPageChange(event) {
    this.config.currentPage = event;

  }
  onsearchFormSubmit() {
    this.submitted = true;
    var search_param = "";

    if (this.show_date == true) {
      search_param = this.SearchForm.get('fileterdate').value;
      this.SearchForm.controls['fileterdate'].updateValueAndValidity();
      if (this.SearchForm.invalid) {
        return;
      }
    } else {
      search_param = this.SearchForm.get('searchkey').value;
      this.SearchForm.controls['fileterdate'].setErrors(null);
    }

    let NewEnrollment = {
      'searchkey': search_param,
      'searchfield': document.getElementById('searchfield').textContent
    };
  
    this.EnrollmentService.searchEnrollment(NewEnrollment).subscribe(data => {
      this.Enrollmentlist.length = 0;
      if (data['error'] == true) {
        return;
      } else {
        Object.assign(this.Enrollmentlist, data);
        this.TotalRec=this.Enrollmentlist['result'].length;
      }
    });

  }

  refresh() {
    this.SearchForm.controls['searchkey'].reset('');
    this.EnrollmentService.getEnrollmentList().subscribe(data => {
      console.log(data);
        Object.assign(this.Enrollmentlist, data);
        this.TotalRec=this.Enrollmentlist['result'].length;
    }, error => {
      console.log("Error while getting Enrollments!", error);
    });
  }

   resetSearch() {
     this.SearchForm.controls['searchkey'].reset('');
   }

   getEnrollment() {
    this.EnrollmentService.getEnrollmentList().subscribe(data => {
        Object.assign(this.Enrollmentlist, data);
        this.TotalRec=this.Enrollmentlist['result'].length;
    }, error => {
      console.log("Error while getting Enrollments!", error);
    });
  }

  addNewEnrollments() {
    this.bsModalRef = this.bsModalService.show(AddNewEnrollmentComponent, { class: 'modal-lg1', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        this.getEnrollment();
      }
    });
  }

  AddSubject(enrollid: number) {
    this.EnrollmentService.changeEnrollmentId(enrollid);
    this.bsModalRefSubject = this.bsModalService.show(AddNewEnrollmentSubjectComponent , { class: 'modal-lg1', backdrop: 'static', keyboard: false });
    this.bsModalRefSubject.content.event.subscribe(result => {
      if (result == 'OK') {
        this.getEnrollment();
      }
    });
  }

  EditSubject(enrollid: number) {
    this.EnrollmentService.changeEnrollmentId(enrollid);
    this.bsModalRef = this.bsModalService.show(EditEnrollmentComponent , { class: 'modal-lg1', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        this.getEnrollment();
      }
    });
  }

  // DeleteLevels(LevelsId: number) {
  //   this.bsModalRef = this.bsModalService.show(DeleteLevelsComponent, { class: 'modal-md', backdrop: 'static', keyboard: false });
  //   this.bsModalRef.content.LevelsId = LevelsId;
  //   this.bsModalRef.content.event.subscribe(result => {
  //     if (result == 'OK') {
  //       this.Levelslist = [];
  //       this.getLevels();
  //     }
  //   });
  // }

  // // EnabledisableUser(userId: number, state: number){
  // //   if (state==1){
  // //     this.state=0;
  // //   }else{
  // //     this.state=1;
  // //   }
  // //   this.UsersService.EnabledisableUser(userId, this.state).subscribe(result=>{
  // //     this.getUsers();
  // //   });
  // // }
}
