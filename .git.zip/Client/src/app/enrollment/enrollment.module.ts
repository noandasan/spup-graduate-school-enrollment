import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ng6-toastr-notifications';
import { NgxPaginationModule } from 'ngx-pagination';
import { BoxModule } from 'angular-admin-lte';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { EnrollmentRoutingModule } from './enrollment-routing.module';
import { EnrollmentComponent } from './enrollment.component';
 import { AddNewEnrollmentComponent } from './add-new-enrollment/add-new-enrollment.component';
// import { EditLevelsComponent } from './edit-levels/edit-levels.component';
//  import { DeleteLevelsComponent } from './delete-levels/delete-levels.component';
import {IMaskModule} from 'angular-imask';
import { NgSelectModule } from '@ng-select/ng-select';
import { AddNewEnrollmentSubjectComponent } from './add-new-enrollment-subject/add-new-enrollment-subject.component';
import { EditEnrollmentComponent } from './edit-enrollment/edit-enrollment.component';

@NgModule({ 
  declarations: [
    EnrollmentComponent,
    AddNewEnrollmentComponent,
    AddNewEnrollmentSubjectComponent,
    EditEnrollmentComponent,
    //  EditLevelsComponent,
    //  DeleteLevelsComponent,

],
  imports: [
    CommonModule,
    EnrollmentRoutingModule,
    BoxModule,
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    NgxPaginationModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    NgSelectModule


  ],
  providers: [BsModalService],
  entryComponents:[AddNewEnrollmentComponent, AddNewEnrollmentSubjectComponent, EditEnrollmentComponent]
 
})
export class EnrollmentModule { }


