import { Component, OnInit, Input, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { UsersService } from '../users.service';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-edit-users',
  templateUrl: './edit-users.component.html',
  styleUrls: ['./edit-users.component.css']
})
export class EditUsersComponent implements OnInit {

  EditUser: FormGroup;
  submitted = false;
  UserId: number;
  UserData: any;
  event: EventEmitter<any> = new EventEmitter();

  constructor(
    private builder: FormBuilder,
    private UsersService: UsersService, 
    private bsModalRef: BsModalRef,
    public toastr: ToastrManager
  ) { 

    this.UsersService.userIdData.subscribe(data => {
      this.UserId = data;
      if (this.UserId !== undefined) {
        this.UsersService.getUserId(this.UserId).subscribe(data => {
        
          this.UserData = data;

          if (this.EditUser != null && this.UserData != null) {
            this.EditUser.controls['email'].setValue(this.UserData.User.email);
            this.EditUser.controls['password'].setValue(this.UserData.User.password);
            this.EditUser.controls['firstname'].setValue(this.UserData.User.firstname);
            this.EditUser.controls['lastname'].setValue(this.UserData.User.lastname);
          }
        }, error => { console.log("Error while gettig user details") });
      }
    });

  }
 get f() { return this.EditUser.controls; }

 onUserEdit() {
    this.submitted = true;
    let UserData = {
      'id': this.UserId,
      'email': this.EditUser.get('email').value,
      'firstname': this.EditUser.get('firstname').value,
      'lastname': this.EditUser.get('lastname').value,
    };
    if (this.EditUser.invalid) {
        return;
    }

      this.UsersService.UpdateUser(UserData).subscribe(data => {
      this.event.emit('OK'); 
      this.bsModalRef.hide();
      this.toastr.successToastr('User Successfully Updated.', '', {
        position: 'top-right',
        animate: 'slideFromTop',
      });
     
    });
  }
  onClose() {
    this.bsModalRef.hide();
  }
  ngOnInit() {
     this.EditUser = this.builder.group({
      email: new FormControl({value: '', disabled: true},[Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required, Validators.minLength(6)]),
      firstname: new FormControl('', [Validators.required]),
      lastname: new FormControl('', [Validators.required])
    });

  }
}