import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';

import { UsersService } from '../users.service';

@Component({
  selector: 'app-add-new-users',
  templateUrl: './add-new-users.component.html',
  styleUrls: ['./add-new-users.component.css']
})
export class AddNewUsersComponent implements OnInit {

  addNewUser: FormGroup;
  event: EventEmitter<any> = new EventEmitter();
  submitted = false;


  constructor(
    private builder: FormBuilder,
    private UsersService: UsersService,
    private bsModalRef: BsModalRef, 
    public toastr: ToastrManager
  ) {
    
   }

  ngOnInit() {
    this.addNewUser = this.builder.group({
      email: new FormControl('', [Validators.required, Validators.email]),
      password: new FormControl('', [Validators.required, Validators.minLength(6)]),
      firstname: new FormControl('', [Validators.required]),
      lastname: new FormControl('', [Validators.required])
    });
  }
  //closemodal
  onClose() {
    this.bsModalRef.hide();
  }

  get f() { return this.addNewUser.controls; }

//form submit
  onNewUser() {
    this.submitted = true;
    let NewUsers = {
      'email': this.addNewUser.get('email').value,
      'password': this.addNewUser.get('password').value,
      'firstname': this.addNewUser.get('firstname').value,
      'lastname': this.addNewUser.get('lastname').value
    };

    if (this.addNewUser.invalid) {
      return;
    }
    this.UsersService.addNewuser(NewUsers).subscribe(data => {
      if (data['error']==true){
        this.toastr.errorToastr('Email already exist Saved.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
        return;
      }else{
        this.event.emit('OK');
        this.bsModalRef.hide();
        this.toastr.successToastr('Successfully Saved.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
      }
       
    });
  }
}
