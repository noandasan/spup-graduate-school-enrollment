import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, from } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { BehaviorSubject } from "rxjs";
import { Globals } from '../global';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  private readonly Users: string;
  
  userIdSource = new  BehaviorSubject<number>(0);
  userIdData: any;

  constructor(private http: HttpClient, private Globals: Globals) { 
    this.Users = Globals.baseUrl;
    this.userIdData= this.userIdSource.asObservable();
  }

  getUserList() {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Users + "getUsers", { headers: header })
  }
  registerUser(post: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Users + "RegisterUser", post, { headers: header })
  }

  addNewuser(post: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Users + "AddUsers", post, { headers: header })
  }
  searchUser(post: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Users + "SearchUsers", post, { headers: header })
  }
  getUserId(UserId: number) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Users + "GetUserId/UserId/" + UserId, { headers: header })
  }
  changeUserId(UserId: number) {
    this.userIdSource.next(UserId);
  }
  UpdateUser(UserId: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Users + "UpdateUser", UserId, { headers: header })
  }
  DeleteUser(UserId: number){
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Users + "DeleteUser/UserId/" +UserId, { headers: header})
}

EnabledisableUser(UserId: number, State: number) {
  let header = new HttpHeaders();
  header.append('Content-Type', 'applications/json');
  return this.http.post(this.Users + "EnabledisableUser/UserId/"+ UserId+"/State/"+ State, { headers: header })
}

 handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}