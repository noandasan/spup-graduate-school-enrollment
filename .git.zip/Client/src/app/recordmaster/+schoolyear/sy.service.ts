import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, from } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { BehaviorSubject } from "rxjs";
import { Globals } from '../../global';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class SYService {
  private readonly SY: string;
  
  SYIdSource = new  BehaviorSubject<number>(0);
  SYIdData: any;

  constructor(private http: HttpClient, private Globals: Globals) { 
    this.SY = Globals.baseUrl;
    this.SYIdData= this.SYIdSource.asObservable();
  }

  getSYList() {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.SY + "getSY", { headers: header })
  }

  getSYList1() {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.SY + "getSY1", { headers: header })
  }

  addNewSY(SYData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.SY + "AddSY", SYData, { headers: header })
  }
  searchSY(SYData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.SY + "SearchSY", SYData, { headers: header })
  }
  getSYId(SYId: number) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.SY + "GetSYId/SYId/" + SYId, { headers: header })
  }
  changeSYId(SYId: number) {
    this.SYIdSource.next(SYId);
  }
  UpdateSY(SYId: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.SY + "UpdateSY", SYId, { headers: header })
  }
  DeleteSY(SYId: number){
   
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.SY + "DeleteSY/SYId/" +SYId, { headers: header})
}

EnabledisableSY(id: number, State: number) {
  let header = new HttpHeaders();
  header.append('Content-Type', 'applications/json');
  return this.http.post(this.SY + "EnabledisableSY/id/"+ id+"/State/"+ State, { headers: header })
}
  
 handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}