import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ng6-toastr-notifications';
import { NgxPaginationModule } from 'ngx-pagination';
import { BoxModule } from 'angular-admin-lte';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { SYRoutingModule } from './sy-routing.module';
import { SYComponent } from './sy.component';
import { AddNewSyComponent } from './add-new-sy/add-new-sy.component';
import { EditSyComponent } from './edit-sy/edit-sy.component';
import { DeleteSyComponent } from './delete-sy/delete-sy.component';
import {IMaskModule} from 'angular-imask';

@NgModule({ 
  declarations: [
    SYComponent,
    AddNewSyComponent,
    EditSyComponent,
    DeleteSyComponent,

],
  imports: [
    CommonModule,
    SYRoutingModule,
    BoxModule,
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    NgxPaginationModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    IMaskModule


  ],
  providers: [BsModalService],
  entryComponents:[AddNewSyComponent, EditSyComponent, DeleteSyComponent]
 
})
export class SYModule { }


