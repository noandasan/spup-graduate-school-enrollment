import { Component, OnInit, Input, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { SYService } from '../sy.service';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';
@Component({
  selector: 'app-edit-sy',
  templateUrl: './edit-sy.component.html',
  styleUrls: ['./edit-sy.component.css']
})
export class EditSyComponent implements OnInit {

  EditSY: FormGroup;
  submitted = false;
  SYId: number;
  SYData: any;
  loading: boolean;
  event: EventEmitter<any> = new EventEmitter();

  constructor(
    private builder: FormBuilder,
    private SYService: SYService, 
    private bsModalRef: BsModalRef,
    public toastr: ToastrManager
  ) {
    this.SYService.SYIdData.subscribe(data => {
      this.SYId = data;
      if (this.SYId !== undefined) {
        this.SYService.getSYId(this.SYId).subscribe(data => {
          this.SYData = data;
          if (this.EditSY != null && this.SYData != null) {
            this.EditSY.controls['schoolyear'].setValue(this.SYData.result.sy);
          }
        }, error => { console.log("Error while gettig school year details") });
      }
    });
   }

   get f() { return this.EditSY.controls; }

   onEdit() {
      this.submitted = true;
      let SYData = {
        'id': this.SYId,
        'schoolyear': this.EditSY.get('schoolyear').value
      };
      if (this.EditSY.invalid) {
          return;
      }
      this.loading=true;
        this.SYService.UpdateSY(SYData).subscribe(data => {
        this.event.emit('OK'); 
        this.loading=false;
        this.bsModalRef.hide();
        this.toastr.successToastr('User Successfully Updated.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
       
      });
    }
    onClose() {
      this.bsModalRef.hide();
    }
    ngOnInit() {
       this.EditSY = this.builder.group({
        schoolyear: new FormControl('',[Validators.required])
      });
  
    }
}
