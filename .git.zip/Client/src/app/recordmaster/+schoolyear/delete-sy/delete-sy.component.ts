import { Component, OnInit, EventEmitter } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { SYService } from '../sy.service';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-delete-sy',
  templateUrl: './delete-sy.component.html',
  styleUrls: ['./delete-sy.component.css']
})
export class DeleteSyComponent implements OnInit {
  SYId: number;
  title: string;
  event: EventEmitter<any> = new EventEmitter();
  constructor(
    private bsModalRef: BsModalRef,
    private SYService: SYService, 
    public toastr: ToastrManager
  ) { }

  DeleteSYconfirm(SYId: number) {
    this.SYService.DeleteSY(SYId).subscribe();
    this.event.emit('OK');
    this.bsModalRef.hide();
    this.toastr.successToastr('School Year Successfully Deleted.', '', {
      position: 'top-right',
      animate: 'slideFromTop',
    });
   
  }

  onClose() {
    this.bsModalRef.hide();
  }
  ngOnInit() {
  }

}
