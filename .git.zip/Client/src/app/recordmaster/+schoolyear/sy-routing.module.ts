import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SYComponent } from './sy.component';
import { AuthGuard } from '../../guards/auth-guard.service';

const routes: Routes = [{
  path: '',
  component:SYComponent
},
{
  
}];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SYRoutingModule { }
