import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { SubjectsService } from '../../+subjects/subjects.service';
import { ToastrManager } from 'ng6-toastr-notifications';
import { SemestersService } from '../../+semesters/semesters.service';
import { SpecializationsService } from '../specializations.service';
import { LevelsService } from '../../+levels/levels.service';

@Component({
  selector: 'app-add-subject',
  templateUrl: './add-subject.component.html',
  styleUrls: ['./add-subject.component.css']
})
export class AddSubjectComponent implements OnInit {

  addNewSubject: FormGroup;
  event: EventEmitter<any> = new EventEmitter();
  submitted = false;
  loading: boolean;
  SubjectList: any[] = [];
  SemesterList: any[] = [];
  PrerequisiteList: any[] = [];
  LevelList: any[]=[];

  SubjectOfferedList: any[]=[];

  SpecializationsId: number;
  SpecializationsData: any;

  constructor(
    private builder: FormBuilder,
    private bsModalRef: BsModalRef, 
    public toastr: ToastrManager,
    private SubjectsService: SubjectsService,
    private SemesterService: SemestersService,
    private SpecializationsService: SpecializationsService,
    private LevelService: LevelsService

  ) {

    this.SpecializationsService.SpecializationsIdData.subscribe(data => {
      this.SpecializationsId = data;
      if (this.SpecializationsId !== undefined) {
        this.SpecializationsService.getSpecializationsIdSubject(this.SpecializationsId).subscribe(data => {
          Object.assign(this.SubjectList, data);
          Object.assign(this.PrerequisiteList, data);

          this.SpecializationsService.loadSubjectOffer(this.SpecializationsId).subscribe(data =>{
               Object.assign(this.SubjectOfferedList, data);
          })

        }, error => { console.log("Error while gettig specialization details") });
      }
    });
   }

  onClose() {
    this.bsModalRef.hide();
  }

  ngOnInit() {
    this.addNewSubject = this.builder.group({
      subjectid: new FormControl('', [Validators.required]),
      levelid: new FormControl('', [Validators.required]),
      semesterid: new FormControl('', [Validators.required]),
      subjectpre: new FormControl(''),
      units: new FormControl('', [Validators.required])
    })
     this.SemesterService.getSemestersList().subscribe(data => {
      Object.assign(this.SemesterList, data);
     }, error => {
       console.log("Error while getting Semesters ", error);
     });
     this.LevelService.getLevelsList().subscribe(data => {
      Object.assign(this.LevelList, data);
     }, error => {
       console.log("Error while getting Semesters ", error);
     });
  }


  get f() { return this.addNewSubject.controls; }


  onSubmit(){
    this.submitted = true;
    let NewSubject = {
      'subjectid': this.addNewSubject.get('subjectid').value,
      'levelid': this.addNewSubject.get('levelid').value,
      'semesterid': this.addNewSubject.get('semesterid').value,
      'subjectpre': this.addNewSubject.get('subjectpre').value,
      'units': this.addNewSubject.get('units').value,
      'specializationid':this.SpecializationsId
    };
    if (this.addNewSubject.invalid) {
      return;
    }
    
    this.SpecializationsService.AddSubjectoffers(NewSubject).subscribe(data =>{
      if (data['error']==true){
        this.toastr.errorToastr('Subject Already Added.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
      }else{
        Object.assign(this.SubjectOfferedList, data);
        this.toastr.successToastr('Added successfully.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
      }
    })
   
  }
}
