import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, from } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { BehaviorSubject } from "rxjs";
import { Globals } from '../../global';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class SpecializationsService {
  private readonly Specializations: string;
  
  SpecializationsIdSource = new  BehaviorSubject<number>(0);
  SpecializationsIdData: any;

  constructor(private http: HttpClient, private Globals: Globals) { 
    this.Specializations = Globals.baseUrl;
    this.SpecializationsIdData= this.SpecializationsIdSource.asObservable();
  }

  getSpecializationsList() {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Specializations + "getSpecializations", { headers: header })
  }

  addNewSpecializations(SpecializationsData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Specializations + "AddSpecializations", SpecializationsData, { headers: header })
  }

  AddSubjectoffers(SubjectData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Specializations + "AddSubjectoffers", SubjectData, { headers: header })
  }
  

  loadSubjectOffer(SpecializationsId: number) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Specializations + "loadSubjectOffer/SpecializationsId/" + SpecializationsId, { headers: header })
  }


  searchSpecializations(SpecializationsData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Specializations + "SearchSpecializations", SpecializationsData, { headers: header })
  }
  getSpecializationsId(SpecializationsId: number) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Specializations + "GetSpecializationsId/SpecializationsId/" + SpecializationsId, { headers: header })
  }

  getSpecializationsIdSubject(SpecializationsId: number) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Specializations + "GetSpecializationsIdSubject/SpecializationsId/" + SpecializationsId, { headers: header })
  }

  changeSpecializationsId(SpecializationsId: number) {
    this.SpecializationsIdSource.next(SpecializationsId);
  }
  UpdateSpecializations(SpecializationsId: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Specializations + "UpdateSpecializations", SpecializationsId, { headers: header })
  }
  DeleteSpecializations(SpecializationsId: number){
       let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Specializations + "DeleteSpecializations/SpecializationsId/" +SpecializationsId, { headers: header})
}

// EnabledisableUser(UserId: number, State: number) {
//   let header = new HttpHeaders();
//   header.append('Content-Type', 'applications/json');
//   return this.http.post(this.Users + "EnabledisableUser/UserId/"+ UserId+"/State/"+ State, { headers: header })
// }
  
 handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}