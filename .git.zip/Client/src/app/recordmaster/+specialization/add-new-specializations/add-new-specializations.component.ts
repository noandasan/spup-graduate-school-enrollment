import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';

import { SpecializationsService } from '../specializations.service';
import { CoursesService } from '../../+courses/courses.service';

@Component({
  selector: 'app-add-new-specializations',
  templateUrl: './add-new-specializations.component.html',
  styleUrls: ['./add-new-specializations.component.css']
})
export class AddNewSpecializationsComponent implements OnInit {
  addNewSpecializations: FormGroup;
  event: EventEmitter<any> = new EventEmitter();
  submitted = false;
  loading: boolean;
  CourseList: any[] = [];
  constructor(
    private builder: FormBuilder,
    private SpecializationsService: SpecializationsService,
    private bsModalRef: BsModalRef, 
    public toastr: ToastrManager,
    private CoursesService: CoursesService
    ) { }

  ngOnInit() {
    this.addNewSpecializations = this.builder.group({
      specialization: new FormControl('', [Validators.required]),
      courseId: new FormControl('', [Validators.required])
    })
    this.CoursesService.getCoursesList ().subscribe(data => {
      Object.assign(this.CourseList, data);
     }, error => {
       console.log("Error while getting Course ", error);
     });
  }
  onClose() {
    this.bsModalRef.hide();
  }

  get f() { return this.addNewSpecializations.controls; }

  onSubmit() {
    this.submitted = true;
    let NewSpecializations = {
      'specialization': this.addNewSpecializations.get('specialization').value,
      'courseId': this.addNewSpecializations.get('courseId').value

    };

    if (this.addNewSpecializations.invalid) {
      return;
    }
    this.loading=true;
    this.SpecializationsService.addNewSpecializations(NewSpecializations).subscribe(data => {
      if (data['error']==true){
        this.toastr.errorToastr('Specialization already exist.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
        this.loading=false;
        return;
      }else{
        this.loading=false;
        this.event.emit('OK');
        this.bsModalRef.hide();
        this.toastr.successToastr('Successfully Saved.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
      }
       
    });
  }


}
