import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ng6-toastr-notifications';
import { NgxPaginationModule } from 'ngx-pagination';
import { BoxModule } from 'angular-admin-lte';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgSelectModule } from '@ng-select/ng-select';

import { SpecializationsRoutingModule } from './specializations-routing.module';
import { SpecializationsComponent } from './specializations.component';
import { AddNewSpecializationsComponent } from './add-new-specializations/add-new-specializations.component';
import { EditSpecializationsComponent } from './edit-specializations/edit-specializations.component';
import { DeleteSpecializationsComponent } from './delete-specializations/delete-specializations.component';
import { AddSubjectComponent } from './add-subject/add-subject.component';

@NgModule({ 
  declarations: [
    SpecializationsComponent,
    AddNewSpecializationsComponent,
    EditSpecializationsComponent,
    DeleteSpecializationsComponent,
    AddSubjectComponent,
    

],
  imports: [
    CommonModule,
    SpecializationsRoutingModule,
    BoxModule,
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    NgxPaginationModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    NgSelectModule


  ],
  providers: [BsModalService],
  entryComponents:[AddNewSpecializationsComponent, EditSpecializationsComponent, DeleteSpecializationsComponent, AddSubjectComponent]
 
})
export class SpecializationsModule { }


