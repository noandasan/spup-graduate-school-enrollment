import { Component, OnInit, Input, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { SpecializationsService } from '../specializations.service';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';
import { CoursesService } from '../../+courses/courses.service';

@Component({
  selector: 'app-edit-specializations',
  templateUrl: './edit-specializations.component.html',
  styleUrls: ['./edit-specializations.component.css']
})
export class EditSpecializationsComponent implements OnInit {
  EditSpecializations: FormGroup;
  submitted = false;
  SpecializationsId: number;
  SpecializationsData: any;
  loading: boolean;
  event: EventEmitter<any> = new EventEmitter();
  CourseList: any[] = [];
  constructor(
    private builder: FormBuilder,
    private SpecializationsService: SpecializationsService, 
    private bsModalRef: BsModalRef,
    public toastr: ToastrManager,
    private CoursesService: CoursesService
  ) { 

    this.CoursesService.getCoursesList().subscribe(data => {
      Object.assign(this.CourseList, data);
     }, error => {
       console.log("Error while getting Course ", error);
     });

    this.SpecializationsService.SpecializationsIdData.subscribe(data => {
      this.SpecializationsId = data;
      if (this.SpecializationsId !== undefined) {
        this.SpecializationsService.getSpecializationsId(this.SpecializationsId).subscribe(data => {
          this.SpecializationsData = data;
          if (this.EditSpecializations != null && this.SpecializationsData != null) {
            this.EditSpecializations.controls['courseId'].setValue(this.SpecializationsData.result.courseid);
            this.EditSpecializations.controls['specialization'].setValue(this.SpecializationsData.result.specialization);
          }
        }, error => { console.log("Error while gettig specialization details") });
      }
    });
  }

  get f() { return this.EditSpecializations.controls; }

  onEdit() {
      this.submitted = true;
      let SpecializationsData = {
        'id': this.SpecializationsId,
        'specialization': this.EditSpecializations.get('specialization').value,
        'courseId': this.EditSpecializations.get('courseId').value
      };
      if (this.EditSpecializations.invalid) {
          return;
      }
      this.loading=true;
        this.SpecializationsService.UpdateSpecializations(SpecializationsData).subscribe(data => {
        this.event.emit('OK'); 
        this.loading=false;
        this.bsModalRef.hide();
        this.toastr.successToastr('Specialization Successfully Updated.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
       
      });
    }
    onClose() {
      this.bsModalRef.hide();
    }
    ngOnInit() {
       this.EditSpecializations = this.builder.group({
        specialization: new FormControl('', [Validators.required]),
        courseId: new FormControl('', [Validators.required])
      });
  
    }


}
