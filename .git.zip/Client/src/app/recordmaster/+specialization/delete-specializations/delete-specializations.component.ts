import { Component, OnInit, EventEmitter } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { SpecializationsService } from '../specializations.service';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-delete-specializations',
  templateUrl: './delete-specializations.component.html',
  styleUrls: ['./delete-specializations.component.css']
})
export class DeleteSpecializationsComponent implements OnInit {
  SpecializationsId: number;
  title: string;
  event: EventEmitter<any> = new EventEmitter();
  constructor(
    private bsModalRef: BsModalRef,
    private SpecializationsService: SpecializationsService, 
    public toastr: ToastrManager
  ) { }

  DeleteSpecializationsconfirm(SpecializationsId: number) {
    this.SpecializationsService.DeleteSpecializations(SpecializationsId).subscribe();
    this.event.emit('OK');
    this.bsModalRef.hide();
    this.toastr.successToastr('Specialization Successfully Deleted.', '', {
      position: 'top-right',
      animate: 'slideFromTop',
    });
   
  }

  onClose() {
    this.bsModalRef.hide();
  }
  ngOnInit() {
  }



}
