import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SpecializationsComponent } from './specializations.component';
import { AuthGuard } from '../../guards/auth-guard.service';

const routes: Routes = [{
  path: '',
  component: SpecializationsComponent
},
{
  
}];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SpecializationsRoutingModule { }
