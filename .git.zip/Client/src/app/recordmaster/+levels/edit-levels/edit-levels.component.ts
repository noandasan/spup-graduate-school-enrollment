import { Component, OnInit, Input, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { LevelsService } from '../levels.service';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';
@Component({
  selector: 'app-edit-levels',
  templateUrl: './edit-levels.component.html',
  styleUrls: ['./edit-levels.component.css']
})
export class EditLevelsComponent implements OnInit {

  EditLevels: FormGroup;
  submitted = false;
  LevelsId: number;
  LevelsData: any;
  loading: boolean;
  event: EventEmitter<any> = new EventEmitter();

  constructor(
    private builder: FormBuilder,
    private LevelsService: LevelsService, 
    private bsModalRef: BsModalRef,
    public toastr: ToastrManager
  ) {
    this.LevelsService.LevelsIdData.subscribe(data => {
      this.LevelsId = data;
     
      if (this.LevelsId !== undefined) {
        this.LevelsService.getLevelsId(this.LevelsId).subscribe(data => {
          this.LevelsData = data;
          
          if (this.EditLevels != null && this.LevelsData != null) {
            this.EditLevels.controls['level'].setValue(this.LevelsData.result.level);
          }
        }, error => { console.log("Error while gettig Level details") });
      }
    });
   }

   get f() { return this.EditLevels.controls; }

   onEdit() {
      this.submitted = true;
      let LevelsData = {
        'id': this.LevelsId,
        'level': this.EditLevels.get('level').value
      };
      if (this.EditLevels.invalid) {
          return;
      }
      this.loading=true;
        this.LevelsService.UpdateLevels(LevelsData).subscribe(data => {
        this.event.emit('OK'); 
        this.loading=false;
        this.bsModalRef.hide();
        this.toastr.successToastr('Level Successfully Updated.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
       
      });
    }
    onClose() {
      this.bsModalRef.hide();
    }
    ngOnInit() {
       this.EditLevels = this.builder.group({
        level: new FormControl('',[Validators.required])
      });
  
    }
}
