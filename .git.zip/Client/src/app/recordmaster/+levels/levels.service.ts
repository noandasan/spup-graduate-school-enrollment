import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, from } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { BehaviorSubject } from "rxjs";
import { Globals } from '../../global';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class LevelsService {
  private readonly Levels: string;
  
  LevelsIdSource = new  BehaviorSubject<number>(0);
  LevelsIdData: any;

  constructor(private http: HttpClient, private Globals: Globals) { 
    this.Levels = Globals.baseUrl;
    this.LevelsIdData= this.LevelsIdSource.asObservable();
  }

  getLevelsList() {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Levels + "getLevels", { headers: header })
  }

  addNewLevels(LevelsData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Levels + "AddLevels", LevelsData, { headers: header })
  }
  searchLevels(LevelsData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Levels + "SearchLevels", LevelsData, { headers: header })
  }
getLevelsId(LevelsId: number) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Levels + "GetLevelsId/LevelsId/" + LevelsId, { headers: header })
  }
changeLevelsId(LevelsId: number) {
    this.LevelsIdSource.next(LevelsId);
  }
  UpdateLevels(LevelsId: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Levels + "UpdateLevels", LevelsId, { headers: header })
  }
  DeleteLevels(LevelsId: number){
   
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Levels + "DeleteLevels/LevelsId/" +LevelsId, { headers: header})
}

// EnabledisableUser(UserId: number, State: number) {
//   let header = new HttpHeaders();
//   header.append('Content-Type', 'applications/json');
//   return this.http.post(this.Users + "EnabledisableUser/UserId/"+ UserId+"/State/"+ State, { headers: header })
// }
  
 handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}