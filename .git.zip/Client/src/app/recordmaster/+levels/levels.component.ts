import { Component, OnInit, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';


import { LevelsService } from './levels.service';
import { AddNewLevelsComponent } from './add-new-levels/add-new-levels.component';
import { EditLevelsComponent } from './edit-levels/edit-levels.component';
 import { DeleteLevelsComponent } from './delete-levels/delete-levels.component';

@Component({
  selector: 'app-levels',
  templateUrl: './levels.component.html',
  styleUrls: ['./levels.component.css']
})
export class LevelsComponent implements OnInit {
 
  bsModalRef: BsModalRef;
  SearchForm: FormGroup;
  submitted = false;
  Levelslist: any[] = [];
  event: EventEmitter<any> = new EventEmitter();

  myDateValue: Date;
  show_normal: boolean;
  show_date: boolean;
  valid: boolean;
  TotalRec: number;

  state: number;

  config = {
    itemsPerPage: 0,
    currentPage: 0,
    totalItems:0
  };

  public maxSize: number = 20;
  public directionLinks: boolean = true;
  public autoHide: boolean = false;
  public responsive: boolean = true;
  public labels: any = {
    previousLabel: '',
    nextLabel: '',
    screenReaderPaginationLabel: 'Pagination',
    screenReaderPageLabel: 'page',
    screenReaderCurrentLabel: `You're on page`
  };


  constructor(
    private builder: FormBuilder, 
    private bsModalService: BsModalService,
    private LevelsService: LevelsService
  ){ 
    this.getLevels();

    this.config = {
      itemsPerPage: 20,
      currentPage: 1,
      totalItems: this.TotalRec
    };

    this.show_normal = true;
    this.valid = false;
    this.show_date = false;


  }

  ngOnInit() {
    this.SearchForm = this.builder.group({
      searchkey: new FormControl('', []),
      fileterdate: new FormControl('', [Validators.required])
    });
    this.myDateValue = new Date();
  }


   get f() { return this.SearchForm.controls; }

  SearchfieldSet(val) {
    document.getElementById('searchfield').innerHTML = val + ' <span class="fa fa-caret-down"></span>';
    if (val.toLowerCase() === 'created') {
      this.show_normal = false;
      this.show_date = true;
      this.SearchForm.controls['fileterdate'].updateValueAndValidity();
    } else {
      this.show_normal = true;
      this.show_date = false;
      this.SearchForm.controls['fileterdate'].setErrors(null);
    }

  }

  onPageChange(event) {
    this.config.currentPage = event;

  }
  onsearchFormSubmit() {
    this.submitted = true;
    var search_param = "";

    if (this.show_date == true) {
      search_param = this.SearchForm.get('fileterdate').value;
      this.SearchForm.controls['fileterdate'].updateValueAndValidity();
      if (this.SearchForm.invalid) {
        return;
      }
    } else {
      search_param = this.SearchForm.get('searchkey').value;
      this.SearchForm.controls['fileterdate'].setErrors(null);
    }

    let NewLevels = {
      'searchkey': search_param,
      'searchfield': document.getElementById('searchfield').textContent
    };
  
    this.LevelsService.searchLevels(NewLevels).subscribe(data => {
      this.Levelslist.length = 0;
      if (data['error'] == true) {
        return;
      } else {
        Object.assign(this.Levelslist, data);
        this.TotalRec=this.Levelslist['result'].length;
      }
    });

  }

  refresh() {
    this.SearchForm.controls['searchkey'].reset('');
    // this.SYService.getSYList().subscribe(data => {
    //   Object.assign(this.SYlist, data);
    //   this.TotalRec=this.SYlist['result'].length;
    // }, error => {
    //   console.log("Error while getting School Year ", error);
    // });
  }

   resetSearch() {
     this.SearchForm.controls['searchkey'].reset('');
   }

  getLevels() {
    this.LevelsService.getLevelsList().subscribe(data => {
        Object.assign(this.Levelslist, data);
        this.TotalRec=this.Levelslist['result'].length;
    }, error => {
      console.log("Error while getting Users ", error);
    });
  }
  addNewLevels() {
    this.bsModalRef = this.bsModalService.show(AddNewLevelsComponent, { class: 'modal-md', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        this.getLevels();
      }
    });
  }

  EditLevels(LevelsId: number) {
    this.LevelsService.changeLevelsId(LevelsId);
    this.bsModalRef = this.bsModalService.show(EditLevelsComponent, { class: 'modal-md', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        this.getLevels();
      }
    });
  }

  DeleteLevels(LevelsId: number) {
    this.bsModalRef = this.bsModalService.show(DeleteLevelsComponent, { class: 'modal-md', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.LevelsId = LevelsId;
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        this.Levelslist = [];
        this.getLevels();
      }
    });
  }

  // // EnabledisableUser(userId: number, state: number){
  // //   if (state==1){
  // //     this.state=0;
  // //   }else{
  // //     this.state=1;
  // //   }
  // //   this.UsersService.EnabledisableUser(userId, this.state).subscribe(result=>{
  // //     this.getUsers();
  // //   });
  // // }
}
