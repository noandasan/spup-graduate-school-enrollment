import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ng6-toastr-notifications';
import { NgxPaginationModule } from 'ngx-pagination';
import { BoxModule } from 'angular-admin-lte';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { LevelsRoutingModule } from './levels-routing.module';
import { LevelsComponent } from './levels.component';
import { AddNewLevelsComponent } from './add-new-levels/add-new-levels.component';
import { EditLevelsComponent } from './edit-levels/edit-levels.component';
 import { DeleteLevelsComponent } from './delete-levels/delete-levels.component';
import {IMaskModule} from 'angular-imask';

@NgModule({ 
  declarations: [
    LevelsComponent,
     AddNewLevelsComponent,
     EditLevelsComponent,
     DeleteLevelsComponent,

],
  imports: [
    CommonModule,
    LevelsRoutingModule,
    BoxModule,
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    NgxPaginationModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    IMaskModule


  ],
  providers: [BsModalService],
  entryComponents:[AddNewLevelsComponent, EditLevelsComponent, DeleteLevelsComponent]
 
})
export class LevelsModule { }


