import { Component, OnInit, EventEmitter } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { LevelsService } from '../levels.service';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-delete-levels',
  templateUrl: './delete-levels.component.html',
  styleUrls: ['./delete-levels.component.css']
})
export class DeleteLevelsComponent implements OnInit {
  SYId: number;
  title: string;
  event: EventEmitter<any> = new EventEmitter();
  constructor(
    private bsModalRef: BsModalRef,
    private LevelsService: LevelsService, 
    public toastr: ToastrManager
  ) { }

  DeleteLevelsconfirm(LevelsId: number) {
    this.LevelsService.DeleteLevels(LevelsId).subscribe();
    this.event.emit('OK');
    this.bsModalRef.hide();
    this.toastr.successToastr('Level Successfully Deleted.', '', {
      position: 'top-right',
      animate: 'slideFromTop',
    });
   
  }

  onClose() {
    this.bsModalRef.hide();
  }
  ngOnInit() {
  }

}
