import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';

import { LevelsService } from '../levels.service';

@Component({
  selector: 'app-add-new-levels',
  templateUrl: './add-new-levels.component.html',
  styleUrls: ['./add-new-levels.component.css']
})
export class AddNewLevelsComponent implements OnInit {

  addNewLevels: FormGroup;
  event: EventEmitter<any> = new EventEmitter();
  submitted = false;
  loading: boolean;

  constructor(
    private builder: FormBuilder,
    private LevelsService: LevelsService,
    private bsModalRef: BsModalRef, 
    public toastr: ToastrManager
  ) { }

  ngOnInit() {
    this.addNewLevels = this.builder.group({
      level: new FormControl('', [Validators.required])
    })
  }
  onClose() {
    this.bsModalRef.hide();
  }

  get f() { return this.addNewLevels.controls; }

  onSubmit() {
    this.submitted = true;
    let NewLevels = {
      'level': this.addNewLevels.get('level').value
    };

    if (this.addNewLevels.invalid) {
      return;
    }
    this.loading=true;
    this.LevelsService.addNewLevels(NewLevels).subscribe(data => {
      if (data['error']==true){
        this.toastr.errorToastr('School year already exist.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
        this.loading=false;
        return;
      }else{
        this.loading=false;
        this.event.emit('OK');
        this.bsModalRef.hide();
        this.toastr.successToastr('Successfully Saved.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
      }
       
    });
  }

}
