import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SubjectsComponent } from './subjects.component';
import { AuthGuard } from '../../guards/auth-guard.service';

const routes: Routes = [{
  path: '',
  component: SubjectsComponent
},
{
  
}];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SubjectsRoutingModule { }
