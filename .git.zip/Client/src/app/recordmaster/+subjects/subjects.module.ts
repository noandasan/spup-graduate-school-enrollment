import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ng6-toastr-notifications';
import { NgxPaginationModule } from 'ngx-pagination';
import { BoxModule } from 'angular-admin-lte';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgSelectModule } from '@ng-select/ng-select';

import { SubjectsRoutingModule } from './subjects-routing.module';
import { SubjectsComponent } from './subjects.component';
import { AddNewSubjectsComponent } from './add-new-subjects/add-new-subjects.component';
import { EditSubjectsComponent } from './edit-subjects/edit-subjects.component';
import { DeleteSubjectsComponent } from './delete-subjects/delete-subjects.component';

@NgModule({ 
  declarations: [
    SubjectsComponent,
    AddNewSubjectsComponent,
    EditSubjectsComponent,
    DeleteSubjectsComponent,
   

],
  imports: [
    CommonModule,
    SubjectsRoutingModule,
    BoxModule,
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    NgxPaginationModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    NgSelectModule


  ],
  providers: [BsModalService],
  entryComponents:[ AddNewSubjectsComponent,
    EditSubjectsComponent,
    DeleteSubjectsComponent,]
 
})
export class SubjectsModule { }


