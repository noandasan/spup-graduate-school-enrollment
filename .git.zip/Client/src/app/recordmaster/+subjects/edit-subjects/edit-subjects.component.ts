import { Component, OnInit, Input, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { SubjectsService } from '../subjects.service';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';
import { SpecializationsService } from '../../+specialization/specializations.service';

@Component({
  selector: 'app-edit-subjects',
  templateUrl: './edit-subjects.component.html',
  styleUrls: ['./edit-subjects.component.css']
})
export class EditSubjectsComponent implements OnInit {
  EditSubjects: FormGroup;
  submitted = false;
  SubjectsId: number;
  SubjectsData: any;
  loading: boolean;
  event: EventEmitter<any> = new EventEmitter();
  SpecializationList: any[] = [];
  constructor(
    private builder: FormBuilder,
    private SpecializationsService: SpecializationsService, 
    private bsModalRef: BsModalRef,
    public toastr: ToastrManager,
    private SubjectsService: SubjectsService
  ) { 

    this.SpecializationsService.getSpecializationsList ().subscribe(data => {
      Object.assign(this.SpecializationList, data);
     }, error => {
       console.log("Error while getting Specialization ", error);
     });

    this.SubjectsService.SubjectsIdData.subscribe(data => {
      this.SubjectsId = data;
      if (this.SubjectsId !== undefined) {
        this.SubjectsService.getSubjectsId(this.SubjectsId).subscribe(data => {
          this.SubjectsData = data;
          if (this.EditSubjects != null && this.SubjectsData != null) {
            this.EditSubjects.controls['specializationid'].setValue(this.SubjectsData.result.specializationid);
            this.EditSubjects.controls['subject'].setValue(this.SubjectsData.result.subject);
          }
        }, error => { console.log("Error while gettig subject details") });
      }
    });
  }

  get f() { return this.EditSubjects.controls; }

  onSubmit() {
      this.submitted = true;
      let SubjectsData = {
        'id': this.SubjectsId,
        'subject': this.EditSubjects.get('subject').value,
        'specializationid': this.EditSubjects.get('specializationid').value
      };
      if (this.EditSubjects.invalid) {
          return;
      }
      this.loading=true;
        this.SubjectsService.UpdateSubjects(SubjectsData).subscribe(data => {
        this.event.emit('OK'); 
        this.loading=false;
        this.bsModalRef.hide();
        this.toastr.successToastr('Subject Successfully Updated.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
       
      });
    }
    onClose() {
      this.bsModalRef.hide();
    }
    ngOnInit() {
       this.EditSubjects = this.builder.group({
        subject: new FormControl('', [Validators.required]),
        specializationid: new FormControl('', [Validators.required])
      });
  
    }


}
