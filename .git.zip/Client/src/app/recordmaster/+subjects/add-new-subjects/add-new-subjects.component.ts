import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';

import { SubjectsService } from '../subjects.service';
import { SpecializationsService } from '../../+specialization/specializations.service';

@Component({
  selector: 'app-add-new-subjects',
  templateUrl: './add-new-subjects.component.html',
  styleUrls: ['./add-new-subjects.component.css']
})
export class AddNewSubjectsComponent implements OnInit {
  addNewSubjects: FormGroup;
  event: EventEmitter<any> = new EventEmitter();
  submitted = false;
  loading: boolean;
  SpecializationList: any[] = [];
 

  constructor(
    private builder: FormBuilder,
    private SpecializationsService: SpecializationsService,
    private bsModalRef: BsModalRef, 
    public toastr: ToastrManager,
    private SubjectsService: SubjectsService
  ) { }

  ngOnInit() {
    this.addNewSubjects = this.builder.group({
      subject: new FormControl('', [Validators.required]),
      specializationid: new FormControl('', [Validators.required])
    })
    this.SpecializationsService.getSpecializationsList ().subscribe(data => {
      Object.assign(this.SpecializationList, data);
     }, error => {
       console.log("Error while getting Specialization ", error);
     });
  }
  onClose() {
    this.bsModalRef.hide();
  }

  get f() { return this.addNewSubjects.controls; }

  onSubmit() {
    this.submitted = true;
    let NewSpecializations = {
      'subject': this.addNewSubjects.get('subject').value,
      'specializationid': this.addNewSubjects.get('specializationid').value

    };

    if (this.addNewSubjects.invalid) {
      return;
    }
    this.loading=true;
    this.SubjectsService.addNewSubjects(NewSpecializations).subscribe(data => {
      if (data['error']==true){
        this.toastr.errorToastr('Subjects already exist.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
        this.loading=false;
        return;
      }else{
        this.loading=false;
        this.event.emit('OK');
        this.bsModalRef.hide();
        this.toastr.successToastr('Successfully Saved.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
      }
       
    });
  }


}
