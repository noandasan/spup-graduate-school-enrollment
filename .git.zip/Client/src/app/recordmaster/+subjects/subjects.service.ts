import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, from } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { BehaviorSubject } from "rxjs";
import { Globals } from '../../global';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class SubjectsService {
  private readonly Subjects: string;
  
  SubjectsIdSource = new  BehaviorSubject<number>(0);
  SubjectsIdData: any;

  constructor(private http: HttpClient, private Globals: Globals) { 
    this.Subjects = Globals.baseUrl;
    this.SubjectsIdData= this.SubjectsIdSource.asObservable();
  }

  getSubjectsList() {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Subjects + "getSubjects", { headers: header })
  }
  getSubjectsListPre() {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Subjects + "getSubjectsPre", { headers: header })
  }

  addNewSubjects(SubjectsData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Subjects + "AddSubjects", SubjectsData, { headers: header })
  }
  searchSubjects(SubjectsData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Subjects + "SearchSubjects", SubjectsData, { headers: header })
  }
  getSubjectsId(SubjectsId: number) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Subjects + "GetSubjectsId/SubjectsId/" + SubjectsId, { headers: header })
  }
  changeSubjectsId(SubjectsId: number) {
    this.SubjectsIdSource.next(SubjectsId);
  }
  UpdateSubjects(SubjectsId: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Subjects + "UpdateSubjects",SubjectsId, { headers: header })
  }
  DeleteSubjects(SubjectsId: number){
   
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Subjects + "DeleteSubjects/SubjectsId/" +SubjectsId, { headers: header})
}

// EnabledisableUser(UserId: number, State: number) {
//   let header = new HttpHeaders();
//   header.append('Content-Type', 'applications/json');
//   return this.http.post(this.Users + "EnabledisableUser/UserId/"+ UserId+"/State/"+ State, { headers: header })
// }
  
 handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}