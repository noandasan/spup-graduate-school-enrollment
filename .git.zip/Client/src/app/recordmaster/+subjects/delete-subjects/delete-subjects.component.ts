import { Component, OnInit, EventEmitter } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { SubjectsService } from '../subjects.service';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-delete-subjects',
  templateUrl: './delete-subjects.component.html',
  styleUrls: ['./delete-subjects.component.css']
})
export class DeleteSubjectsComponent implements OnInit {
  SubjectsId: number;
  title: string;
  event: EventEmitter<any> = new EventEmitter();
  constructor(
    private bsModalRef: BsModalRef,
    private SubjectsService: SubjectsService, 
    public toastr: ToastrManager
  ) { }

  DeleteSubjectsconfirm(SubjectsId: number) {
    this.SubjectsService.DeleteSubjects(SubjectsId).subscribe();
    this.event.emit('OK');
    this.bsModalRef.hide();
    this.toastr.successToastr('Subject Successfully Deleted.', '', {
      position: 'top-right',
      animate: 'slideFromTop',
    });
   
  }

  onClose() {
    this.bsModalRef.hide();
  }
  ngOnInit() {
  }


}
