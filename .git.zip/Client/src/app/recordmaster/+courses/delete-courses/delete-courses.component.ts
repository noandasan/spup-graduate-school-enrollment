import { Component, OnInit, EventEmitter } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { CoursesService } from '../courses.service';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-delete-courses',
  templateUrl: './delete-courses.component.html',
  styleUrls: ['./delete-courses.component.css']
})
export class DeleteCoursesComponent implements OnInit {
  CoursesId: number;
  title: string;
  event: EventEmitter<any> = new EventEmitter();
  constructor(
    private bsModalRef: BsModalRef,
    private CoursesService: CoursesService, 
    public toastr: ToastrManager
  ) { }

  DeleteCoursesconfirm(CoursesId: number) {
    this.CoursesService.DeleteCourses(CoursesId).subscribe();
    this.event.emit('OK');
    this.bsModalRef.hide();
    this.toastr.successToastr('Course Successfully Deleted.', '', {
      position: 'top-right',
      animate: 'slideFromTop',
    });
   
  }

  onClose() {
    this.bsModalRef.hide();
  }
  ngOnInit() {
  }


}
