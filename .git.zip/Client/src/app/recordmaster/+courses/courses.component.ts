import { Component, OnInit, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';


import { CoursesService } from './courses.service';
import { AddNewCoursesComponent } from './add-new-courses/add-new-courses.component';
import { EditCoursesComponent } from './edit-courses/edit-courses.component';
import { DeleteCoursesComponent } from './delete-courses/delete-courses.component';


@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})
export class CoursesComponent implements OnInit {
 
  bsModalRef: BsModalRef;
  SearchForm: FormGroup;
  submitted = false;
  Courseslist: any[] = [];
  event: EventEmitter<any> = new EventEmitter();

  myDateValue: Date;
  show_normal: boolean;
  show_date: boolean;
  valid: boolean;
  TotalRec: number;

  state: number;

  config = {
    itemsPerPage: 0,
    currentPage: 0,
    totalItems:0
  };

  public maxSize: number = 20;
  public directionLinks: boolean = true;
  public autoHide: boolean = false;
  public responsive: boolean = true;
  public labels: any = {
    previousLabel: '',
    nextLabel: '',
    screenReaderPaginationLabel: 'Pagination',
    screenReaderPageLabel: 'page',
    screenReaderCurrentLabel: `You're on page`
  };


  constructor(
    private builder: FormBuilder, 
    private bsModalService: BsModalService,
    private CoursesService: CoursesService
  ){ 
    this.getCourses();

    this.config = {
      itemsPerPage: 20,
      currentPage: 1,
      totalItems: this.TotalRec
    };

    this.show_normal = true;
    this.valid = false;
    this.show_date = false;


  }

  ngOnInit() {
    this.SearchForm = this.builder.group({
      searchkey: new FormControl('', []),
      fileterdate: new FormControl('', [Validators.required])
    });
    this.myDateValue = new Date();
  }


  get f() { return this.SearchForm.controls; }

  SearchfieldSet(val) {
    document.getElementById('searchfield').innerHTML = val + ' <span class="fa fa-caret-down"></span>';
    if (val.toLowerCase() === 'created') {
      this.show_normal = false;
      this.show_date = true;
      this.SearchForm.controls['fileterdate'].updateValueAndValidity();
    } else {
      this.show_normal = true;
      this.show_date = false;
      this.SearchForm.controls['fileterdate'].setErrors(null);
    }

  }

  onPageChange(event) {
    this.config.currentPage = event;

  }
  onsearchFormSubmit() {
    this.submitted = true;
    var search_param = "";

    if (this.show_date == true) {
      search_param = this.SearchForm.get('fileterdate').value;
      this.SearchForm.controls['fileterdate'].updateValueAndValidity();
      if (this.SearchForm.invalid) {
        return;
      }
    } else {
      search_param = this.SearchForm.get('searchkey').value;
      this.SearchForm.controls['fileterdate'].setErrors(null);
    }

    let NewCourses = {
      'searchkey': search_param,
      'searchfield': document.getElementById('searchfield').textContent
    };
  
    this.CoursesService.searchCourses(NewCourses).subscribe(data => {
      this.Courseslist.length = 0;
      if (data['error'] == true) {
        return;
      } else {
        Object.assign(this.Courseslist, data);
        this.TotalRec=this.Courseslist['result'].length;
      }
    });

  }

  refresh() {
    this.SearchForm.controls['searchkey'].reset('');
    this.CoursesService.getCoursesList().subscribe(data => {
      Object.assign(this.Courseslist, data);
      this.TotalRec=this.Courseslist['result'].length;
    }, error => {
      console.log("Error while getting Courses ", error);
    });
  }

   resetSearch() {
     this.SearchForm.controls['searchkey'].reset('');
   }

  getCourses() {
    this.CoursesService.getCoursesList().subscribe(data => {
        Object.assign(this.Courseslist, data);
        this.TotalRec=this.Courseslist['result'].length;
    }, error => {
      console.log("Error while Courses ", error);
    });
  }
  addNewCourses() {
    this.bsModalRef = this.bsModalService.show(AddNewCoursesComponent, { class: 'modal-md', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        this.getCourses();
      }
    });
  }

  EditCourses(CoursesId: number) {
    this.CoursesService.changeCoursesId(CoursesId);
    this.bsModalRef = this.bsModalService.show(EditCoursesComponent, { class: 'modal-md', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        this.getCourses();
      }
    });
  }

  DeleteCourses(CoursesId: number) {
    this.bsModalRef = this.bsModalService.show(DeleteCoursesComponent, { class: 'modal-md', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.CoursesId = CoursesId;
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        this.Courseslist = [];
        this.getCourses();
      }
    });
  }

  // EnabledisableUser(userId: number, state: number){
  //   if (state==1){
  //     this.state=0;
  //   }else{
  //     this.state=1;
  //   }
  //   this.UsersService.EnabledisableUser(userId, this.state).subscribe(result=>{
  //     this.getUsers();
  //   });
  // }
}
