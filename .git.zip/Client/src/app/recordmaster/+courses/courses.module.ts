import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ng6-toastr-notifications';
import { NgxPaginationModule } from 'ngx-pagination';
import { BoxModule } from 'angular-admin-lte';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { CoursesRoutingModule } from './courses-routing.module';
import { CoursesComponent } from './courses.component';
import { AddNewCoursesComponent } from './add-new-courses/add-new-courses.component';
import { EditCoursesComponent } from './edit-courses/edit-courses.component';
import { DeleteCoursesComponent } from './delete-courses/delete-courses.component';

@NgModule({ 
  declarations: [
    CoursesComponent,
    AddNewCoursesComponent,
    EditCoursesComponent,
    DeleteCoursesComponent,

],
  imports: [
    CommonModule,
    CoursesRoutingModule,
    BoxModule,
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    NgxPaginationModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),


  ],
  providers: [BsModalService],
  entryComponents:[AddNewCoursesComponent, EditCoursesComponent, DeleteCoursesComponent]
 
})
export class CoursesModule { }


