import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';

import { CoursesService } from '../courses.service';

@Component({
  selector: 'app-add-new-courses',
  templateUrl: './add-new-courses.component.html',
  styleUrls: ['./add-new-courses.component.css']
})
export class AddNewCoursesComponent implements OnInit {

  addNewCourses: FormGroup;
  event: EventEmitter<any> = new EventEmitter();
  submitted = false;
  loading: boolean;

  constructor(
    private builder: FormBuilder,
    private CoursesService: CoursesService,
    private bsModalRef: BsModalRef, 
    public toastr: ToastrManager
  ) { }

  ngOnInit() {
    this.addNewCourses = this.builder.group({
      acourse: new FormControl('', [Validators.required]),
      course: new FormControl('', [Validators.required])
    })
  }
  onClose() {
    this.bsModalRef.hide();
  }

  get f() { return this.addNewCourses.controls; }

  onSubmit() {
    this.submitted = true;
    let NewCourses = {
      'acourse': this.addNewCourses.get('acourse').value,
      'course': this.addNewCourses.get('course').value,
    };

    if (this.addNewCourses.invalid) {
      return;
    }
    this.loading=true;
    this.CoursesService.addNewCourses(NewCourses).subscribe(data => {
      if (data['error']==true){
        this.toastr.errorToastr('Course already exist.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
        this.loading=false;
        return;
      }else{
        this.loading=false;
        this.event.emit('OK');
        this.bsModalRef.hide();
        this.toastr.successToastr('Course Saved.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
      }
       
    });
  }
}
