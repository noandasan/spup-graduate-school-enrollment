import { Component, OnInit, Input, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { CoursesService } from '../courses.service';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-edit-courses',
  templateUrl: './edit-courses.component.html',
  styleUrls: ['./edit-courses.component.css']
})
export class EditCoursesComponent implements OnInit {
  EditCourses: FormGroup;
  submitted = false;
  CoursesId: number;
  CoursesData: any;
  loading: boolean;
  event: EventEmitter<any> = new EventEmitter();
  constructor(
    private builder: FormBuilder,
    private CoursesService: CoursesService, 
    private bsModalRef: BsModalRef,
    public toastr: ToastrManager
  ) { 
    this.CoursesService.CoursesIdData.subscribe(data => {
      this.CoursesId = data;
      if (this.CoursesId !== undefined) {
        this.CoursesService.getCoursesId(this.CoursesId).subscribe(data => {
          this.CoursesData = data;
          if (this.EditCourses != null && this.CoursesData != null) {
            this.EditCourses.controls['acourse'].setValue(this.CoursesData.result.acourse);
            this.EditCourses.controls['course'].setValue(this.CoursesData.result.course);
          }
        }, error => { console.log("Error while gettig courses details") });
      }
    });
  }

  get f() { return this.EditCourses.controls; }

  onEdit() {
      this.submitted = true;
      let CoursesData = {
        'id': this.CoursesId,
        'acourse': this.EditCourses.get('acourse').value,
        'course': this.EditCourses.get('course').value
      };
      if (this.EditCourses.invalid) {
          return;
      }
      this.loading=true;
        this.CoursesService.UpdateCourses(CoursesData).subscribe(data => {
        this.event.emit('OK'); 
        this.loading=false;
        this.bsModalRef.hide();
        this.toastr.successToastr('Courses Successfully Updated.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
       
      });
    }
    onClose() {
      this.bsModalRef.hide();
    }
    ngOnInit() {
       this.EditCourses = this.builder.group({
        acourse: new FormControl('',[Validators.required]),
        course: new FormControl('',[Validators.required])
      });
  
    }

}
