import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, from } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { BehaviorSubject } from "rxjs";
import { Globals } from '../../global';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class CoursesService {
  private readonly Courses: string;
  
  CoursesIdSource = new  BehaviorSubject<number>(0);
  CoursesIdData: any;

  constructor(private http: HttpClient, private Globals: Globals) { 
    this.Courses = Globals.baseUrl;
    this.CoursesIdData= this.CoursesIdSource.asObservable();
  }

  getCoursesList() {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Courses + "getCourses", { headers: header })
  }

  addNewCourses(CoursesData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Courses + "AddCourses", CoursesData, { headers: header })
  }
  searchCourses(CoursesData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Courses + "SearchCourses", CoursesData, { headers: header })
  }
  getCoursesId(CoursesId: number) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Courses + "GetCoursesId/CoursesId/" + CoursesId, { headers: header })
  }
  changeCoursesId(CoursesId: number) {
    this.CoursesIdSource.next(CoursesId);
  }
  UpdateCourses(CoursesId: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Courses + "UpdateCourses", CoursesId, { headers: header })
  }
  DeleteCourses(CoursesId: number){
   
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Courses + "DeleteCourses/CoursesId/" +CoursesId, { headers: header})
}

// EnabledisableUser(UserId: number, State: number) {
//   let header = new HttpHeaders();
//   header.append('Content-Type', 'applications/json');
//   return this.http.post(this.Users + "EnabledisableUser/UserId/"+ UserId+"/State/"+ State, { headers: header })
// }
  
 handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}