import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CoursesComponent } from './courses.component';
import { AuthGuard } from '../../guards/auth-guard.service';

const routes: Routes = [{
  path: '',
  component: CoursesComponent
},
{
  
}];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CoursesRoutingModule { }
