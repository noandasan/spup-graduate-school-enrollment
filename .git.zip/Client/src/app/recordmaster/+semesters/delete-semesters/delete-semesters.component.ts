import { Component, OnInit, EventEmitter } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { SemestersService } from '../semesters.service';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-delete-semesters',
  templateUrl: './delete-semesters.component.html',
  styleUrls: ['./delete-semesters.component.css']
})
export class DeleteSemestersComponent implements OnInit {
  SemestersId: number;
  title: string;
  event: EventEmitter<any> = new EventEmitter();
  constructor(
    private bsModalRef: BsModalRef,
    private SemestersService: SemestersService, 
    public toastr: ToastrManager
  ) { }
  DeleteSemestersconfirm(SemestersId: number) {
    this.SemestersService.DeleteSemesters(SemestersId).subscribe();
    this.event.emit('OK');
    this.bsModalRef.hide();
    this.toastr.successToastr('Semester Successfully Deleted.', '', {
      position: 'top-right',
      animate: 'slideFromTop',
    });
   
  }

  onClose() {
    this.bsModalRef.hide();
  }
  ngOnInit() {
  }


}
