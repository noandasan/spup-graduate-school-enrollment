import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, from } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { BehaviorSubject } from "rxjs";
import { Globals } from '../../global';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class SemestersService {
  private readonly Semesters: string;
  
  SemestersIdSource = new  BehaviorSubject<number>(0);
  SemestersIdData: any;

  constructor(private http: HttpClient, private Globals: Globals) { 
    this.Semesters = Globals.baseUrl;
    this.SemestersIdData= this.SemestersIdSource.asObservable();
  }

  getSemestersList() {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Semesters + "getSemesters", { headers: header })
  }

  getSemestersList1() {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Semesters + "getSemesters1", { headers: header })
  }


  addNewSemesters(SemestersData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Semesters + "AddSemesters", SemestersData, { headers: header })
  }
  searchSemesters(SemestersData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Semesters + "SearchSemesters", SemestersData, { headers: header })
  }
  getSemestersId(SemestersId: number) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Semesters + "GetSemestersId/SemestersId/" + SemestersId, { headers: header })
  }
  changeSemestersId(SemestersId: number) {
    this.SemestersIdSource.next(SemestersId);
  }
  UpdateSemesters(SemestersId: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Semesters+ "UpdateSemesters", SemestersId, { headers: header })
  }
  DeleteSemesters(SemestersId: number){
   
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Semesters + "DeleteSemesters/SemestersId/" +SemestersId, { headers: header})
}

EnabledisableSemester(id: number, State: number) {
  let header = new HttpHeaders();
  header.append('Content-Type', 'applications/json');
  return this.http.post(this.Semesters + "EnabledisableSemester/id/"+id+"/State/"+ State, { headers: header })
}
  
 handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}