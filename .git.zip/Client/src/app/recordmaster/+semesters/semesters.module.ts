import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ng6-toastr-notifications';
import { NgxPaginationModule } from 'ngx-pagination';
import { BoxModule } from 'angular-admin-lte';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgSelectModule } from '@ng-select/ng-select';

import { SemestersRoutingModule } from './semesters-routing.module';
import { SemestersComponent } from './semesters.component';
import { AddNewSemestersComponent } from './add-new-semesters/add-new-semesters.component';
import { EditSemestersComponent } from './edit-semesters/edit-semesters.component';
import { DeleteSemestersComponent } from './delete-semesters/delete-semesters.component';
// import { AddNewSyComponent } from './add-new-sy/add-new-sy.component';
// import { EditSyComponent } from './edit-sy/edit-sy.component';
// import { DeleteSyComponent } from './delete-sy/delete-sy.component';


@NgModule({ 
  declarations: [
    SemestersComponent,
    AddNewSemestersComponent,
    EditSemestersComponent,
    DeleteSemestersComponent,
   

],
  imports: [
    CommonModule,
    SemestersRoutingModule,
    BoxModule,
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    NgxPaginationModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    NgSelectModule


  ],
  providers: [BsModalService],
  entryComponents:[AddNewSemestersComponent,
    EditSemestersComponent,
    DeleteSemestersComponent,]
 
})
export class SemestersModule { }


