import { Component, OnInit, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';


import { SemestersService } from './semesters.service';
import { AddNewSemestersComponent } from './add-new-semesters/add-new-semesters.component';
import { EditSemestersComponent } from './edit-semesters/edit-semesters.component';
import { DeleteSemestersComponent } from './delete-semesters/delete-semesters.component';
// import { AddNewSyComponent } from './add-new-sy/add-new-sy.component';
// import { EditSyComponent } from './edit-sy/edit-sy.component';
// import { DeleteSyComponent } from './delete-sy/delete-sy.component';

@Component({
  selector: 'app-semesters',
  templateUrl: './semesters.component.html',
  styleUrls: ['./semesters.component.css']
})
export class SemestersComponent implements OnInit {
 
  bsModalRef: BsModalRef;
  SearchForm: FormGroup;
  submitted = false;
  Semesterslist: any[] = [];
  event: EventEmitter<any> = new EventEmitter();

  myDateValue: Date;
  show_normal: boolean;
  show_date: boolean;
  valid: boolean;
  TotalRec: number;

  state: number;

  config = {
    itemsPerPage: 0,
    currentPage: 0,
    totalItems:0
  };

  public maxSize: number = 20;
  public directionLinks: boolean = true;
  public autoHide: boolean = false;
  public responsive: boolean = true;
  public labels: any = {
    previousLabel: '',
    nextLabel: '',
    screenReaderPaginationLabel: 'Pagination',
    screenReaderPageLabel: 'page',
    screenReaderCurrentLabel: `You're on page`
  };


  constructor(
    private builder: FormBuilder, 
    private bsModalService: BsModalService,
    private SemestersService: SemestersService
  ){ 
    this.getSemesters();

    this.config = {
      itemsPerPage: 20,
      currentPage: 1,
      totalItems: this.TotalRec
    };

    this.show_normal = true;
    this.valid = false;
    this.show_date = false;


  }

  ngOnInit() {
    this.SearchForm = this.builder.group({
      searchkey: new FormControl('', []),
      fileterdate: new FormControl('', [Validators.required])
    });
    this.myDateValue = new Date();
  }


  get f() { return this.SearchForm.controls; }

  SearchfieldSet(val) {
    document.getElementById('searchfield').innerHTML = val + ' <span class="fa fa-caret-down"></span>';
    if (val.toLowerCase() === 'created') {
      this.show_normal = false;
      this.show_date = true;
      this.SearchForm.controls['fileterdate'].updateValueAndValidity();
    } else {
      this.show_normal = true;
      this.show_date = false;
      this.SearchForm.controls['fileterdate'].setErrors(null);
    }

  }

  onPageChange(event) {
    this.config.currentPage = event;

  }
  onsearchFormSubmit() {
    this.submitted = true;
    var search_param = "";

    if (this.show_date == true) {
      search_param = this.SearchForm.get('fileterdate').value;
      this.SearchForm.controls['fileterdate'].updateValueAndValidity();
      if (this.SearchForm.invalid) {
        return;
      }
    } else {
      search_param = this.SearchForm.get('searchkey').value;
      this.SearchForm.controls['fileterdate'].setErrors(null);
    }

    let NewSemesters = {
      'searchkey': search_param,
      'searchfield': document.getElementById('searchfield').textContent
    };
  
    this.SemestersService.searchSemesters(NewSemesters).subscribe(data => {
      this.Semesterslist.length = 0;
      if (data['error'] == true) {
        return;
      } else {
        Object.assign(this.Semesterslist, data);
        this.TotalRec=this.Semesterslist['result'].length;
      }
    });

  }

  refresh() {
    this.SearchForm.controls['searchkey'].reset('');
    this.SemestersService.getSemestersList().subscribe(data => {
      Object.assign(this.Semesterslist, data);
      this.TotalRec=this.Semesterslist['result'].length;
    }, error => {
      console.log("Error while getting Semesters ", error);
    });
  }

   resetSearch() {
     this.SearchForm.controls['searchkey'].reset('');
   }

  getSemesters() {
    this.SemestersService.getSemestersList().subscribe(data => {
        Object.assign(this.Semesterslist, data);
        this.TotalRec=this.Semesterslist['result'].length;
    }, error => {
      console.log("Error while Courses ", error);
    });
  }
  addNewSemesters() {
    this.bsModalRef = this.bsModalService.show(AddNewSemestersComponent, { class: 'modal-md', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        this.getSemesters();
      }
    });
  }

  EditSemesters(SemestersId: number) {
    this.SemestersService.changeSemestersId(SemestersId);
    this.bsModalRef = this.bsModalService.show(EditSemestersComponent, { class: 'modal-md', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        this.getSemesters();
      }
    });
  }

  DeleteSemesters(SemestersId: number) {
    this.bsModalRef = this.bsModalService.show(DeleteSemestersComponent, { class: 'modal-md', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.SemestersId = SemestersId;
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        this.Semesterslist = [];
        this.getSemesters();
      }
    });
  }

  EnabledisableSemester(id: number, state: number){
    if (state==1){
      this.state=0;
    }else{
      this.state=1;
    }
    this.SemestersService.EnabledisableSemester(id, this.state).subscribe(result=>{
      this.getSemesters();
    });
  }
}
