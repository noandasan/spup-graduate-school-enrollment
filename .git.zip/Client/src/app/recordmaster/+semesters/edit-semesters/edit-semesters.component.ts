import { Component, OnInit, Input, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { SemestersService } from '../semesters.service';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';
import { SYService } from '../../+schoolyear/sy.service';

@Component({
  selector: 'app-edit-semesters',
  templateUrl: './edit-semesters.component.html',
  styleUrls: ['./edit-semesters.component.css']
})
export class EditSemestersComponent implements OnInit {
  EditSemesters: FormGroup;
  submitted = false;
  SemestersId: number;
  SemestersData: any;
  loading: boolean;
  event: EventEmitter<any> = new EventEmitter();
  

  constructor(
    private builder: FormBuilder,
    private SemestersService: SemestersService, 
    private bsModalRef: BsModalRef,
    public toastr: ToastrManager,
    private SYService: SYService
  ) {
      this.SemestersService.SemestersIdData.subscribe(data => {
      this.SemestersId = data;
      if (this.SemestersId !== undefined) {
        this.SemestersService.getSemestersId(this.SemestersId).subscribe(data => {
          this.SemestersData = data;
          if (this.EditSemesters != null && this.SemestersData != null) {
            this.EditSemesters.controls['semester'].setValue(this.SemestersData.result.semester);
          }
        }, error => { console.log("Error while gettig semesters") });
      }
    });
   }

   get f() { return this.EditSemesters.controls; }

   onSubmit() {
      this.submitted = true;
       let SemestersData = {
         'id': this.SemestersId,
         'semester': this.EditSemesters.get('semester').value
       };
       if (this.EditSemesters.invalid) {
           return;
       }
       this.loading=true;
         this.SemestersService.UpdateSemesters(SemestersData).subscribe(data => {
         this.event.emit('OK'); 
         this.loading=false;
         this.bsModalRef.hide();
         this.toastr.successToastr('Semesters Successfully Updated.', '', {
           position: 'top-right',
           animate: 'slideFromTop',
         });
      });
     }
     onClose() {
       this.bsModalRef.hide();
     }
     ngOnInit() {
        this.EditSemesters = this.builder.group({
         semester: new FormControl('', [Validators.required])
       });
   
     }

}
