import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';

import { SemestersService } from '../semesters.service';
import { SYService } from '../../+schoolyear/sy.service';

@Component({
  selector: 'app-add-new-semesters',
  templateUrl: './add-new-semesters.component.html',
  styleUrls: ['./add-new-semesters.component.css']
})
export class AddNewSemestersComponent implements OnInit {

  addNewSemesters: FormGroup;
  event: EventEmitter<any> = new EventEmitter();
  submitted = false;
  loading: boolean;
  SYList: any[] = [];

  constructor(
    private builder: FormBuilder,
    private SemestersService: SemestersService,
    private bsModalRef: BsModalRef, 
    public toastr: ToastrManager,
    private SYService: SYService
  ) { }

  ngOnInit() {
    this.addNewSemesters = this.builder.group({
      semester: new FormControl('', [Validators.required])     
    })
    this.SYService.getSYList ().subscribe(data => {
      Object.assign(this.SYList, data);
     }, error => {
       console.log("Error while getting school year ", error);
     });
  }
  onClose() {
    this.bsModalRef.hide();
  }

  get f() { return this.addNewSemesters.controls; }

  onSubmit() {
    this.submitted = true;
    let NewSemesters = {
      'semester': this.addNewSemesters.get('semester').value
    };

    if (this.addNewSemesters.invalid) {
      return;
    }
    this.loading=true;
    this.SemestersService.addNewSemesters(NewSemesters).subscribe(data => {
      if (data['error']==true){
        this.toastr.errorToastr('School year already exist.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
        this.loading=false;
        return;
      }else{
        this.loading=false;
        this.event.emit('OK');
        this.bsModalRef.hide();
        this.toastr.successToastr('Successfully Saved.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
      }
       
    });
  }

}
