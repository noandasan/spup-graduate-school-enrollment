import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';

import { ProfileService  } from '../profile.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  ChangePassword: FormGroup;
  event: EventEmitter<any> = new EventEmitter();
  loading: boolean;
  userId: number;
  passwordDidnotMatch: boolean;
  passwordIsInvalid: boolean;
  submitted = false;

  constructor(
    private builder: FormBuilder, 
    private bsModalRef: BsModalRef,
    private ProfileService: ProfileService,
    private toastr: ToastrManager,
  ) {
    
    this.ProfileService.userIdData.subscribe(data => {
      this.userId=data;
    });
   }
   get f() { return this.ChangePassword.controls; }

  onChangePassword() {
    this.loading = true;
    this.submitted=true;
    let passwordData = {
      'id': this.userId,
      'currentpassword': this.ChangePassword.get('currentpassword').value,
      'password': this.ChangePassword.get('password').value
    };
    
    if (this.ChangePassword.invalid) {
      this.loading = false;
      return;
    }
  
   if(this.ChangePassword.controls['repassword'].value!=this.ChangePassword.controls['password'].value){
    this.loading = false;
    this.passwordDidnotMatch=true;
    return;
   }

    this.loading = true;
    this.ProfileService.ChangePass(passwordData).subscribe(data => {
      this.loading = false;
      console.log(data['error']);
        if(data['error']==true){
          this.passwordIsInvalid=true;
          return;
        }else{
          this.toastr.successToastr('Password successfully change.', '', {
            position: 'top-right',
            animate: 'slideFromTop',
          });
        }
        this.loading = false;
    });
  }
  onFocus(){
    this.passwordDidnotMatch=false;
    this.passwordIsInvalid=false;
  }
  ngOnInit() {
    this.ChangePassword = this.builder.group({
      currentpassword: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required, Validators.minLength(6)]),
      repassword: new FormControl('', [Validators.required]),
    });
  }
  onClose() {
    this.bsModalRef.hide();
  }

}
