import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, from } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { BehaviorSubject } from "rxjs";
import { Globals } from '../global';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  private readonly Users: string;
  
  userIdSource = new  BehaviorSubject<number>(0);
  userIdData: any;

  constructor(private http: HttpClient, private Globals: Globals) { 
    this.Users = Globals.baseUrl;  
    this.userIdData= this.userIdSource.asObservable();
  }
  getUserList() {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Users + "getUsers", { headers: header })
  }
  getUserId(UserId: number) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Users + "GetUserId/UserId/" + UserId, { headers: header })
  }
  changeUserId(UserId: number) {
    this.userIdSource.next(UserId);
  }
  UpdateUser(UserId: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Users + "UpdateUser", UserId, { headers: header })
  }
  ChangePass(UserId: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Users + "ChangePass", UserId, { headers: header })
  }


  MyProfile(userId: number) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Users + "MyProfile/userId/" + userId, { headers: header })
  }
 
uploadImage(image: any, userId: number) {
  const formData = new FormData();
  formData.append('file', image, image.name);
  return this.http.post(this.Users + "UploadProfile/userId/"+userId, formData);
}

 handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}