import { Component, OnInit, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ProfileService } from './profile.service';
import decode from 'jwt-decode';
import { ToastrManager } from 'ng6-toastr-notifications';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { Globals } from '../global';
import { ImageComponent } from './image/image.component';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
 
  bsModalRef: BsModalRef;
  Profile: FormGroup;
  submitted = false;
  userId: number;
  userData: any;
  event: EventEmitter<any> = new EventEmitter();
  loading: boolean;

  picture: string;
  ProfilePic: string;
  Url: any;
  

  constructor(
    private builder: FormBuilder, 
    private bsModalService: BsModalService,
    private ProfileService: ProfileService,
    private toastr: ToastrManager,
    private globals: Globals,
  ){ 

    const userId=decode(localStorage.getItem("token"));
    this.ProfileService.changeUserId(userId['id']);
    this.userId=userId['id'];

    this.ProfileService.userIdData.subscribe(data => {
      this.userId = data;
      if (this.userId !== undefined) {
        this.ProfileService.MyProfile(this.userId).subscribe(data => {
          this.userData = data;
      
          if (this.Profile != null && this.userData.User != null) {
            this.Profile.controls['email'].setValue(this.userData.User.email);
            this.Profile.controls['firstname'].setValue(this.userData.User.firstname);
            this.Profile.controls['lastname'].setValue(this.userData.User.lastname);
            this.Profile.controls['position'].setValue(this.userData.User.position);
            
            this.picture=this.userData.User.profile;
            this.loadprofile();
          }
        }, error => {
          this.toastr.errorToastr('Error. Please refresh the Page.', 'ERROR', {
            position: 'top-right',
            animate: 'slideFromTop',
          });

        });
      }
    });

  }
  ngOnInit() {
    this.Profile = this.builder.group({
      email: new FormControl({value: '', disabled: true}, [Validators.required]),
      firstname: new FormControl('', [Validators.required]),
      lastname: new FormControl('', [Validators.required]),
      position: new FormControl('', [Validators.required]),
    });
  }
  get f() { return this.Profile.controls; }
  
  onSubmitProfile() {
    this.loading = true;
    this.submitted=true;
    let userData = {
      'id': this.userId,
      'firstname': this.Profile.get('firstname').value,
      'lastname': this.Profile.get('lastname').value,
      'position': this.Profile.get('position').value
     
    };
    if (this.Profile.invalid) {
      this.loading = false;
      return;
    }
    this.loading = true;
    this.ProfileService.UpdateUser(userData).subscribe(data => {

      this.toastr.successToastr('Profile Successfully Updated.', '', {
        position: 'top-right',
        animate: 'slideFromTop',
      });
      this.loading = false;
    });
  }

   ChangePassword(UserId: number) {
    this.ProfileService.changeUserId(UserId);
    this.bsModalRef = this.bsModalService.show(ChangePasswordComponent, { class: 'modal-md', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        console.log("fds");
      }
    });
  }

  loadprofile(){
    if(this.picture){
      this.ProfilePic=this.globals.basedUrlProfile+''+this.picture;
    }else{
      this.ProfilePic=this.globals.basedUrlProfile+'default.jpg';
    }
}
createFormData(event) {
    if (event.target.files && event.target.files[0]){
      var reader=new FileReader();
      reader.onload=(event:any)=>{
        this.Url=event.target.result;
        const initialState = {
          File: event.target.result
        };
        this.ProfileService.changeUserId(this.userId);
        this.bsModalRef = this.bsModalService.show(ImageComponent, {initialState, class: 'modal-md', backdrop: 'static', keyboard: false });
        this.bsModalRef.content.event.subscribe(result => {
          this.ProfileService.uploadImage(result, this.userId).subscribe(result1=>{
              this.ProfilePic=this.globals.basedUrlProfile+''+result1;
              this.toastr.successToastr('Profile picture successfully updated.', '', {
                position: 'top-right',
                animate: 'slideFromTop',
              });

          });
        });
      }
       reader.readAsDataURL(event.target.files[0]);
    }
  }
}
