import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ng6-toastr-notifications';
import { NgxPaginationModule } from 'ngx-pagination';
import { BoxModule } from 'angular-admin-lte';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { ProfileRoutingModule } from './profile-routing.module';
import { ProfileComponent } from './profile.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { ImageComponent } from './image/image.component';
import { ImageCropperModule } from './image-cropper/image-cropper.module';

@NgModule({ 
  declarations: [
  ProfileComponent,
  ChangePasswordComponent,
  ImageComponent

],
  imports: [
    CommonModule,
    ProfileRoutingModule,
    BoxModule,
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    NgxPaginationModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    ImageCropperModule

  ],
  providers: [BsModalService],
  entryComponents:[ChangePasswordComponent, ProfileComponent, ImageComponent]
 
})
export class ProfileModule { }


