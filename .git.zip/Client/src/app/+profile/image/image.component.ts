import { Component, OnInit, ViewChild, EventEmitter } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { ProfileService } from '../profile.service';

import { ImageCroppedEvent } from '../image-cropper/interfaces/image-cropped-event.interface';
import { ImageCropperComponent } from '../image-cropper/component/image-cropper.component';
import decode from 'jwt-decode';



@Component({
  selector: 'app-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.css']
})
export class ImageComponent implements OnInit {
  imageChangedEvent: any = '';
  croppedImage: any = '';
  showCropper = false;

  userId: number;
  file: any;
  event: EventEmitter<any> = new EventEmitter();

  @ViewChild(ImageCropperComponent) imageCropper: ImageCropperComponent;

  constructor(
    private bsModalRef: BsModalRef,
    private ProfileService: ProfileService
  ) {

    this.ProfileService.userIdData.subscribe(data => {
      this.userId=data;
    });
  }

  fileChangeEvent(event: any): void {
    this.imageChangedEvent = event;
  }
  imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event.base64;
  }
  imageLoaded() {
    this.showCropper = true;

  }
  cropperReady() {
    //console.log('Cropper ready')
  }
  loadImageFailed() {
    console.log('Load failed');
  }
  rotateLeft() {
    this.imageCropper.rotateLeft();
  }
  rotateRight() {
    this.imageCropper.rotateRight();
  }
  flipHorizontal() {
    this.imageCropper.flipHorizontal();
  }
  flipVertical() {
    this.imageCropper.flipVertical();
  }
  ngOnInit() {
  }
  onOK() {
    var blob = this.dataURItoBlob(this.croppedImage);

    var file = new File([blob], this.userId+".jpg", {
      type: "'image/jpeg'"
    });

    this.event.emit(file);
    this.bsModalRef.hide();
  }

  onClose() {
    this.bsModalRef.hide();
  }
  dataURItoBlob(dataURI) {
    var byteString;
    if (dataURI.split(',')[0].indexOf('base64') >= 0)
      byteString = atob(dataURI.split(',')[1]);
    else
      byteString = unescape(dataURI.split(',')[1]);

    var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
    var ia = new Uint8Array(byteString.length);
    for (var i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ia], { type: mimeString });
  }
}
