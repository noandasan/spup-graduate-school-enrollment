import { Injectable } from '@angular/core';

@Injectable()

export class Globals {
  baseUrl: string='http://192.168.1.178:8080/api/';
  basedUrlProfile: string='http://localhost:8080/public/profiles/';
}

