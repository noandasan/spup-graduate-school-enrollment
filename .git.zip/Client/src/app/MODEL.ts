export class Menu {
    label: string;
    route: undefined;
    iconClasses: string;
    'separator': boolean;
}
export class SubMenu {
    label: string;
    route: string;
    iconClasses: string;
    parent: number;
}

export class Users {
    email: string;
    password: string;
    firstname: string;
    lastname: string;
}