import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ng6-toastr-notifications';
import { NgxPaginationModule } from 'ngx-pagination';
import { BoxModule } from 'angular-admin-lte';
import { DatepickerModule, BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { InformationsRoutingModule } from './informations-routing.module';
import { InformationsComponent } from './informations.component';

import { AddNewInformationComponent } from './add-new-information/add-new-information.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { StudentpictureComponent } from './studentpicture/studentpicture.component';
import { ImageCropperModule } from '../../image-cropper/image-cropper.module';
import { EditInformationComponent } from './edit-information/edit-information.component';

@NgModule({ 
  declarations: [
    InformationsComponent,
    AddNewInformationComponent,
    StudentpictureComponent,
    EditInformationComponent
    

],
  imports: [
    CommonModule,
    InformationsRoutingModule,
    BoxModule,
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    NgxPaginationModule,
    BsDatepickerModule.forRoot(),
    DatepickerModule.forRoot(),
    NgSelectModule,
    ImageCropperModule


  ],
  providers: [BsModalService],
  entryComponents:[AddNewInformationComponent, StudentpictureComponent, EditInformationComponent]
 
})
export class InformationsModule { }


