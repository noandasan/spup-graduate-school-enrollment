import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, from } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { BehaviorSubject } from "rxjs";
import { Globals } from '../../global';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable({
  providedIn: 'root'
})
export class InformationsService {
  private readonly Informations: string;
  
  InformationsIdSource = new  BehaviorSubject<string>('');
  InformationsIdData: any;

  constructor(private http: HttpClient, private Globals: Globals) { 
    this.Informations = Globals.baseUrl;
    this.InformationsIdData= this.InformationsIdSource.asObservable();
  }

  getInformationsList() {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Informations + "getInformations", { headers: header })
  }

  uploadImage(image: any) {
    const formData = new FormData();
    formData.append('file', image, image.name);
    return this.http.post(this.Informations + "UploadProfile", formData);
  }

  addNewInformations(InformationsData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Informations + "AddInformations", InformationsData, { headers: header })

  }

  searchInformations(InformationsData: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Informations + "SearchInformations", InformationsData, { headers: header })
  }

  getInformationsId(InformationsId: string) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.get(this.Informations + "GetInformationsId/InformationsId/" + InformationsId, { headers: header })
  }

  changeInformationsId(InformationsId: string) {
    this.InformationsIdSource.next(InformationsId);
  }

  UpdateInformations(InformationsId: any) {
    let header = new HttpHeaders();
    header.append('Content-Type', 'applications/json');
    return this.http.post(this.Informations + "UpdateInformations", InformationsId, { headers: header })
  }

//   DeleteInformations(InformationsId: number){
   
//     let header = new HttpHeaders();
//     header.append('Content-Type', 'applications/json');
//     return this.http.get(this.Informations + "DeleteInformations/InformationsId/" +InformationsId, { headers: header})
// }

// // EnabledisableUser(UserId: number, State: number) {
// //   let header = new HttpHeaders();
// //   header.append('Content-Type', 'applications/json');
// //   return this.http.post(this.Users + "EnabledisableUser/UserId/"+ UserId+"/State/"+ State, { headers: header })
// // }
  
 handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    } else {
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}