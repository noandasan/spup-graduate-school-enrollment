import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';

import { InformationsService } from '../informations.service';
import { StudentpictureComponent } from '../studentpicture/studentpicture.component';
import { Globals } from 'src/app/global';

@Component({
  selector: 'app-add-new-information',
  templateUrl: './add-new-information.component.html',
  styleUrls: ['./add-new-information.component.css']
})
export class AddNewInformationComponent implements OnInit {

  addNewInformations: FormGroup;
  event: EventEmitter<any> = new EventEmitter();
  submitted = false;
  loading: boolean;
  maxDate: Date;
  Age: number;

  picture: any;
  ProfilePic: string;
  Url: any;

  Maritallist = [
    { name: 'Single' },
    { name: 'Married' },
    { name: 'Divorce' },
    { name: 'Separated' }
  ];

  constructor(
    private builder: FormBuilder,
    private InformationsService: InformationsService,
    private bsModalRef: BsModalRef, 
    private bsModalRefimage: BsModalRef,
    public toastr: ToastrManager,
    private bsModalService: BsModalService,
    private globals: Globals
  ) { 
    this.maxDate = new Date();
   
    this.maxDate.setDate(this.maxDate.getDate()-5475);
  }

  ngOnInit() {
    this.addNewInformations = this.builder.group({
      firstname: new FormControl('', [Validators.required]),
      middlename: new FormControl('', [Validators.required]),
      lastname: new FormControl('', [Validators.required]),
      birthdate: new FormControl('', []),
      marital: new FormControl('Single', [Validators.required]),
      sex: new FormControl('Male', [Validators.required]),
      religion: new FormControl('', []),
      contactno: new FormControl('',[]),
      email: new FormControl('',[]),
      presentaddress:new FormControl('',[]),
      permanentaddress:new FormControl('',[]),
      highesteducation: new FormControl('',[]),
      schoolastattended:new FormControl('',[]),
      yearattended:new FormControl('',[])
    })


    this.picture="default.jpg";
    this.Age=0;

    if(this.ProfilePic){
      this.ProfilePic=this.globals.basedUrlProfile+''+this.ProfilePic;
    }else{
      this.ProfilePic=this.globals.basedUrlProfile+'default.jpg';
    }
  }
  onClose() {
    this.bsModalRef.hide();
  }

  getAge(value: Date) {
    var now = new Date()
    var born = new Date(value);
    var years = Math.floor((now.getTime() - born.getTime()) / (365 * 24 * 60 * 60 * 1000));
    this.Age =years
  }
  

  get f() { return this.addNewInformations.controls; }

  onSubmit() {
    this.submitted = true;
    let NewInformation = {
      'firstname': this.addNewInformations.get('firstname').value,
      'middlename': this.addNewInformations.get('middlename').value,
      'lastname': this.addNewInformations.get('lastname').value,
      'birthdate': this.addNewInformations.get('birthdate').value,
      'marital': this.addNewInformations.get('marital').value,
      'sex': this.addNewInformations.get('sex').value,
      'religion': this.addNewInformations.get('religion').value,
      'picture': this.picture,
      'contactno':this.addNewInformations.get('contactno').value,
      'email':this.addNewInformations.get('email').value,
      'presentaddress': this.addNewInformations.get('presentaddress').value,
      'permanentaddress': this.addNewInformations.get('permanentaddress').value,
      'highesteducation':this.addNewInformations.get('highesteducation').value,
      'schoolastattended': this.addNewInformations.get('schoolastattended').value,
      'yearattended': this.addNewInformations.get('yearattended').value
    };
    if (this.addNewInformations.invalid) {
      return;
    }
    this.loading=true;
    this.InformationsService.addNewInformations(NewInformation).subscribe(data => {
      if (data['error']==true){
        this.toastr.errorToastr('Student already exist.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
        this.loading=false;
        return;
      }else{
        this.loading=false;
        this.event.emit('OK');
        this.bsModalRef.hide();
        this.toastr.successToastr('Student Saved.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
      }
       
    });
  }

  numericOnly(event): boolean {    
    let patt = /^([0-9/])$/;
    let result = patt.test(event.key);
    return result;
}

  createFormData(event) {
    if (event.target.files && event.target.files[0]){
      var reader=new FileReader();
      reader.onload=(event:any)=>{
        this.Url=event.target.result;
        const initialState = {
          File: event.target.result
        };
        this.bsModalRefimage = this.bsModalService.show(StudentpictureComponent, {initialState, class: 'modal-md', backdrop: 'static', keyboard: false });
        this.bsModalRefimage.content.event.subscribe(result => {
         this.InformationsService.uploadImage(result).subscribe(result=>{
          this.ProfilePic=this.globals.basedUrlProfile+''+result;
          this.picture=result;
          });
        });
      }
       reader.readAsDataURL(event.target.files[0]);
    }
  }
 
  
  
}
