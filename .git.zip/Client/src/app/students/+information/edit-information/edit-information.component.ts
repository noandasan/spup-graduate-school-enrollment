import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrManager } from 'ng6-toastr-notifications';

import { InformationsService } from '../informations.service';
import { StudentpictureComponent } from '../studentpicture/studentpicture.component';
import { Globals } from 'src/app/global';

@Component({
  selector: 'app-edit-information',
  templateUrl: './edit-information.component.html',
  styleUrls: ['./edit-information.component.css']
})
export class EditInformationComponent implements OnInit {


  EditInformations: FormGroup;
  event: EventEmitter<any> = new EventEmitter();
  submitted = false;
  loading: boolean;
  maxDate: Date;
  Age: number;
  birthdate: Date;

  InformationsId: string;
  InformationsData: any;

  picture: any;
  ProfilePic: string;
  Url: any;

  Maritallist = [
    { name: 'Single' },
    { name: 'Married' },
    { name: 'Divorce' },
    { name: 'Separated' }
  ];

  constructor(
    private builder: FormBuilder,
    private InformationsService: InformationsService,
    private bsModalRef: BsModalRef, 
    private bsModalRefimage: BsModalRef,
    public toastr: ToastrManager,
    private bsModalService: BsModalService,
    private globals: Globals
  ) {
    this.maxDate = new Date();
    this.maxDate.setDate(this.maxDate.getDate()-5475);

    this.InformationsService.InformationsIdData.subscribe(data => {
      this.InformationsId = data;
      if (this.InformationsId !== undefined) {
        this.InformationsService.getInformationsId(this.InformationsId).subscribe(data => {
          this.InformationsData = data;
          if (this.EditInformations != null && this.InformationsData != null) {
            this.EditInformations.controls['studentid'].setValue(this.InformationsData.result.studentid);
            this.EditInformations.controls['firstname'].setValue(this.InformationsData.result.firstname);
            this.EditInformations.controls['middlename'].setValue(this.InformationsData.result.middlename);

            this.EditInformations.controls['lastname'].setValue(this.InformationsData.result.lastname);
            this.EditInformations.controls['sex'].setValue(this.InformationsData.result.sex);
          //  this.EditInformations.controls['birthdate'].setValue(this.InformationsData.result.birthdate);
            this.birthdate=new Date(this.InformationsData.result.birthdate);
            this.EditInformations.controls['marital'].setValue(this.InformationsData.result.marital);
            this.EditInformations.controls['religion'].setValue(this.InformationsData.result.religion);
            this.EditInformations.controls['contactno'].setValue(this.InformationsData.result.contactno);

            this.EditInformations.controls['presentaddress'].setValue(this.InformationsData.result.presentaddress);
            this.EditInformations.controls['permanentaddress'].setValue(this.InformationsData.result.permanentaddress);
            this.EditInformations.controls['highesteducation'].setValue(this.InformationsData.result.highesteducation);

            this.EditInformations.controls['schoolastattended'].setValue(this.InformationsData.result.schoolastattended);
            this.EditInformations.controls['yearattended'].setValue(this.InformationsData.result.yearattended);

            this.ProfilePic=this.InformationsData.result.picture

            
        
            if(this.ProfilePic){
              this.ProfilePic=this.globals.basedUrlProfile+''+this.ProfilePic;
            }else{
              this.ProfilePic=this.globals.basedUrlProfile+'default.jpg';
            }

          }
        }, error => { console.log("Error while gettig student details") });
      }
    });


   }

   ngOnInit() {
    this.EditInformations = this.builder.group({
      studentid: new FormControl('', []),
      firstname: new FormControl('', [Validators.required]),
      middlename: new FormControl('', [Validators.required]),
      lastname: new FormControl('', [Validators.required]),
      birthdate: new FormControl('', []),
      marital: new FormControl('', [Validators.required]),
      sex: new FormControl('', [Validators.required]),
      religion: new FormControl('', []),
      contactno: new FormControl('',[]),
      email: new FormControl('',[]),
      presentaddress:new FormControl('',[]),
      permanentaddress:new FormControl('',[]),
      highesteducation: new FormControl('',[]),
      schoolastattended:new FormControl('',[]),
      yearattended:new FormControl('',[])
    })
   
  }
  onClose() {
    this.bsModalRef.hide();
  }

  getAge(value: Date) {
    var now = new Date()
    var born = new Date(value);
    var years = Math.floor((now.getTime() - born.getTime()) / (365 * 24 * 60 * 60 * 1000));
    this.Age =years
  }
  
  get f() { return this.EditInformations.controls; }

  onSubmit() {
    this.submitted = true;
    let NewInformation = {
      'studentid': this.EditInformations.get('studentid').value,
      'firstname': this.EditInformations.get('firstname').value,
      'middlename': this.EditInformations.get('middlename').value,
      'lastname': this.EditInformations.get('lastname').value,
      'birthdate': this.EditInformations.get('birthdate').value,
      'marital': this.EditInformations.get('marital').value,
      'sex': this.EditInformations.get('sex').value,
      'religion': this.EditInformations.get('religion').value,
      'picture': this.picture,
      'contactno':this.EditInformations.get('contactno').value,
      'email':this.EditInformations.get('email').value,
      'presentaddress': this.EditInformations.get('presentaddress').value,
      'permanentaddress': this.EditInformations.get('permanentaddress').value,
      'highesteducation':this.EditInformations.get('highesteducation').value,
      'schoolastattended': this.EditInformations.get('schoolastattended').value,
      'yearattended': this.EditInformations.get('yearattended').value
    };
    if (this.EditInformations.invalid) {
      return;
    }
    this.loading=true;
    this.InformationsService.UpdateInformations(NewInformation).subscribe(data => {
      this.event.emit('OK'); 
        this.loading=false;
        this.bsModalRef.hide();
        this.toastr.successToastr('Student Information Successfully Updated.', '', {
          position: 'top-right',
          animate: 'slideFromTop',
        });
       
    });
  }

  numericOnly(event): boolean {    
    let patt = /^([0-9/])$/;
    let result = patt.test(event.key);
    return result;
}

  createFormData(event) {
    if (event.target.files && event.target.files[0]){
      var reader=new FileReader();
      reader.onload=(event:any)=>{
        this.Url=event.target.result;
        const initialState = {
          File: event.target.result
        };
        this.bsModalRefimage = this.bsModalService.show(StudentpictureComponent, {initialState, class: 'modal-md', backdrop: 'static', keyboard: false });
        this.bsModalRefimage.content.event.subscribe(result => {
         this.InformationsService.uploadImage(result).subscribe(result=>{
          this.ProfilePic=this.globals.basedUrlProfile+''+result;
          this.picture=result;
          });
        });
      }
       reader.readAsDataURL(event.target.files[0]);
    }
  }
 
  
}
