import { Component, OnInit, EventEmitter} from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

import { InformationsService } from './informations.service';
import { AddNewInformationComponent } from './add-new-information/add-new-information.component';
import { Globals } from 'src/app/global';
import { EditInformationComponent } from './edit-information/edit-information.component';



@Component({
  selector: 'app-informations',
  templateUrl: './informations.component.html',
  styleUrls: ['./informations.component.css']
})
export class InformationsComponent implements OnInit {
 
  bsModalRef: BsModalRef;
  products: number;
  SearchForm: FormGroup;
  submitted = false;
  Studentslist: any[] = [];
  event: EventEmitter<any> = new EventEmitter();
  Url: string;

  myDateValue: Date;
  show_normal: boolean;
  show_date: boolean;
  valid: boolean;
  TotalRec: number;

  state: number;

  config = {
    itemsPerPage: 0,
    currentPage: 0,
    totalItems:0
  };

  public maxSize: number = 32;
  public directionLinks: boolean = true;
  public autoHide: boolean = false;
  public responsive: boolean = true;
  public labels: any = {
    previousLabel: '',
    nextLabel: '',
    screenReaderPaginationLabel: 'Pagination',
    screenReaderPageLabel: 'page',
    screenReaderCurrentLabel: `You're on page`
  };


  constructor(
    private builder: FormBuilder, 
    private bsModalService: BsModalService,
    private InformationsService: InformationsService,
    private globals: Globals
  ){ 
    this.getInformations();

    this.config = {
      itemsPerPage: 32,
      currentPage: 1,
      totalItems: this.TotalRec
    };

    this.show_normal = true;
    this.valid = false;
    this.show_date = false;


  }

  ngOnInit() {
    this.SearchForm = this.builder.group({
      searchkey: new FormControl('', []),
      fileterdate: new FormControl('', [Validators.required])
    });
    this.myDateValue = new Date();
    this.Url=this.globals.basedUrlProfile; 
  }


  get f() { return this.SearchForm.controls; }

  SearchfieldSet(val) {
    document.getElementById('searchfield').innerHTML = val + ' <span class="fa fa-caret-down"></span>';
    if (val.toLowerCase() === 'created') {
      this.show_normal = false;
      this.show_date = true;
      this.SearchForm.controls['fileterdate'].updateValueAndValidity();
    } else {
      this.show_normal = true;
      this.show_date = false;
      this.SearchForm.controls['fileterdate'].setErrors(null);
    }

  }

  onPageChange(event) {
    this.config.currentPage = event;

  }
  onsearchFormSubmit() {
    this.submitted = true;
    var search_param = "";

    if (this.show_date == true) {
      search_param = this.SearchForm.get('fileterdate').value;
      this.SearchForm.controls['fileterdate'].updateValueAndValidity();
      if (this.SearchForm.invalid) {
        return;
      }
    } else {
      search_param = this.SearchForm.get('searchkey').value;
      this.SearchForm.controls['fileterdate'].setErrors(null);
    }

    let NewInformations = {
      'searchkey': search_param,
      'searchfield': document.getElementById('searchfield').textContent
    };
  
    this.InformationsService.searchInformations(NewInformations).subscribe(data => {
      this.Studentslist.length = 0;
      if (data['error'] == true) {
        return;
      } else {
        Object.assign(this.Studentslist, data);
        this.TotalRec=this.Studentslist['result'].length;
      }
    });
  }


  

  refresh() {
    this.SearchForm.controls['searchkey'].reset('');
    this.InformationsService.getInformationsList().subscribe(data => {
      Object.assign(this.Studentslist, data);
      this.TotalRec=this.Studentslist['result'].length;
    }, error => {
      console.log("Error while getting Students Information ", error);
    });
  }

   resetSearch() {
     this.SearchForm.controls['searchkey'].reset('');
   }

  getInformations() {
    this.InformationsService.getInformationsList().subscribe(data => {
        Object.assign(this.Studentslist, data);
        this.TotalRec=this.Studentslist['result'].length;
    }, error => {
      console.log("Error while getting Students Information ", error);
    });
  }
  addNewInformations() {
    this.bsModalRef = this.bsModalService.show(AddNewInformationComponent , { class: 'modal-lg', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        this.getInformations();
      }
    });
  }

  EditInformations(InformationsId: string) {
    this.InformationsService.changeInformationsId(InformationsId);
    this.bsModalRef = this.bsModalService.show(EditInformationComponent, { class: 'modal-lg', backdrop: 'static', keyboard: false });
    this.bsModalRef.content.event.subscribe(result => {
      if (result == 'OK') {
        this.getInformations();
      }
    });
  }

  // DeleteInformations(InformationsId: number) {
  //   this.bsModalRef = this.bsModalService.show(DeleteCoursesComponent, { class: 'modal-md', backdrop: 'static', keyboard: false });
  //   this.bsModalRef.content.InformationsId = InformationsId;
  //   this.bsModalRef.content.event.subscribe(result => {
  //     if (result == 'OK') {
  //       this.Informationslist = [];
  //       this.getInformations();
  //     }
  //   });
  // }

  // EnabledisableUser(userId: number, state: number){
  //   if (state==1){
  //     this.state=0;
  //   }else{
  //     this.state=1;
  //   }
  //   this.UsersService.EnabledisableUser(userId, this.state).subscribe(result=>{
  //     this.getUsers();
  //   });
  // }
}
