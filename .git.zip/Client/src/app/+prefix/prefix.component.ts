import { Component, OnInit, EventEmitter} from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray  } from '@angular/forms';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';


import { PrefixService } from './prefix.service';

@Component({
  selector: 'app-prefix',
  templateUrl: './prefix.component.html',
  styleUrls: ['./prefix.component.css']
})
export class PrefixComponent implements OnInit {

  form: FormGroup;

  constructor(
    private builder: FormBuilder, 
    private PrefixService: PrefixService
  ){ 

    this.form = this.builder.group({
      surgeries: this.builder.array([])
    });

  }

  ngOnInit() {
    
  }

   onAddSurgeries(){
    const control = new FormGroup({
        'surgery': new FormControl("dsa"),
        'illness': new FormControl("dsafff")
    });
      (<FormArray>this.form.get('surgeries')).push(control);
  }
 
}
