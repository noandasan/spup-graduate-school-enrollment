import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { ModalModule, BsModalService } from 'ngx-bootstrap/modal';
import { ToastrModule } from 'ng6-toastr-notifications';
import { NgxPaginationModule } from 'ngx-pagination';
import { BoxModule } from 'angular-admin-lte';


import { PrefixRoutingModule } from './prefix-routing.module';

import { PrefixComponent } from './prefix.component';

@NgModule({ 
  declarations: [
  PrefixComponent,

],
  imports: [
    CommonModule,
    PrefixRoutingModule,
    BoxModule,
    ModalModule.forRoot(),
    FormsModule,
    ReactiveFormsModule,
    ToastrModule.forRoot(),
    NgxPaginationModule,

  ],
  providers: [BsModalService],
  entryComponents:[]
 
})
export class PrefixModule { }


