import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PrefixComponent } from './prefix.component';
import { AuthGuard } from '../guards/auth-guard.service';
import { HomeComponent } from '../home/home.component';

const routes: Routes = [{
  path: '',
  component: PrefixComponent
},
{
  
}];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PrefixRoutingModule { }
