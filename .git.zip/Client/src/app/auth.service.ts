import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, pipe, throwError } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import decode from 'jwt-decode';
import { Globals } from './global';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private message: string;

  constructor(
    private _router: Router,
    private globals: Globals
  ) { }

  clear(): void {
    localStorage.clear();
  }

  isAuthenticated(): boolean {
    return (localStorage.getItem('token') != null && !this.isTokenExpired())
  }

  userID(): number {
    if (this.isAuthenticated) {
      const tokenData = localStorage.getItem('token');
      return tokenData['id'];
    } else {
      this.logout();
    }
  }

  isTokenExpired(): boolean {
    const now = Date.now().valueOf() / 1000
    const dataToken = decode(localStorage.getItem('token'));

    //console.log(dataToken.exp-now);

    if (typeof dataToken.exp !== 'undefined' && dataToken.exp < now) {
      this.logout();
      return true;
    }else{
      return false;
    }


    // var current_time = Date.now() / 1000;
    // if ( jwt.exp < current_time) {
    // /* expired */ 
    // }

    
  }
  login(token: any): void {
    localStorage.setItem('token', token);
  //  const dataToken = decode(token);
      this._router.navigate(['/']);

  }
  logout(): void {
    this.clear();
    this._router.navigate(['/login']);
 
  }
  decode() {
    return localStorage.getItem('token');
  }
}
