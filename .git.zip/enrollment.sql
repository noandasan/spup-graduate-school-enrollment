-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 30, 2019 at 04:02 PM
-- Server version: 10.1.30-MariaDB
-- PHP Version: 7.2.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `enrollment`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcourses`
--

CREATE TABLE `tblcourses` (
  `id` int(11) NOT NULL,
  `acourse` varchar(20) NOT NULL,
  `course` varchar(100) NOT NULL,
  `description` varchar(200) NOT NULL,
  `created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblcourses`
--

INSERT INTO `tblcourses` (`id`, `acourse`, `course`, `description`, `created`) VALUES
(1, 'MSIT', 'Master of Information technology', '', '2019-07-18'),
(2, 'MSBA', 'Master of Science In Business Administration', '', '2019-07-19');

-- --------------------------------------------------------

--
-- Table structure for table `tblinformations`
--

CREATE TABLE `tblinformations` (
  `studentid` varchar(15) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `middlename` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `birthdate` date NOT NULL,
  `marital` varchar(15) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `picture` varchar(200) NOT NULL,
  `contactno` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblinformations`
--

INSERT INTO `tblinformations` (`studentid`, `firstname`, `middlename`, `lastname`, `birthdate`, `marital`, `sex`, `religion`, `picture`, `contactno`, `email`, `created`) VALUES
('2019-11-11', 'e', 'e', 'e', '2019-07-02', 'Married', 'Male', 'e', '1564423129748.jpg', '', '', '2019-07-29'),
('2019-11-12', 'r', 'r', 'ee', '2019-07-01', 'Married', 'Male', 'e', '1564423761717.jpg', '', '', '2019-07-29'),
('2019-11-13', 're', 're', 'rew', '2019-07-03', 'Single', 'Male', 'rrrr', 'default.jpg', '', '', '2019-07-29'),
('2019-11-14', 'villegas', 'villegas', 'oandasan', '2019-07-02', 'Married', 'Male', 'eee', 'default.jpg', '', '', '2019-07-29'),
('2019-11-15', 'Villegas', 'Villegas', 'Oandasan', '2019-07-01', 'Married', 'Male', 'dffdf', '1564424119322.jpg', '', '', '2019-07-29'),
('2019-11-16', 'rew', 'rew', 'rew', '2019-07-03', 'Divorce', 'Male', 'rrrr', 'default.jpg', '', '', '2019-07-29'),
('2019-11-17', 'Monforte', 'Monforte', 'Oandasan', '2019-07-03', 'Married', 'Male', 'eeee', 'default.jpg', '', '', '2019-07-29'),
('2019-11-18', 'Villegas', 'Villegas', 'Oandasan', '2019-07-01', 'Married', 'Male', 'er', '1564424379597.jpg', '', '', '2019-07-29'),
('2019-11-19', 'Offelia', 'Villegas', 'Oandasan', '2019-07-01', 'Married', 'Male', 'Muslim', '1564424630874.jpg', '', '', '2019-07-29'),
('2019-11-20', 'rew', 'rrr', 'rrr', '2019-07-03', 'Divorce', 'Male', 'rrrr', '1564424779893.jpg', '', '', '2019-07-29'),
('2019-11-21', 're', 're', 'rrr', '2019-07-08', 'Divorce', 'Male', 'rrr', '1564424936552.jpg', '', '', '2019-07-29'),
('2019-11-22', 'yt', 'ytr', 'ytry', '2019-07-02', 'Married', 'Male', 'ytytyt', 'default.jpg', '', '', '2019-07-29'),
('2019-11-23', 'Nexson', 'oandasan', 'ofdseqwqeqw', '2019-07-01', 'Divorce', 'Male', 'ew', '1564425250062.jpg', '', '', '2019-07-29'),
('2019-11-24', 'fewr', 'rew', '4324', '2019-07-16', 'Separated', 'Male', '43', '1564425353917.jpg', '', '', '2019-07-29'),
('2019-11-25', 'sa', 'sa', 'sa', '2019-07-16', 'Divorce', 'Male', 'sss', 'default.jpg', '', '', '2019-07-29'),
('2019-11-26', 'dsa', 'dsa', 'dsadsa', '2004-08-01', 'Married', 'Male', 'wwww', '1564433898791.jpg', '', '', '2019-07-29'),
('2019-11-27', 'fds', 'fds', 'fdsf', '2004-07-31', 'Single', 'Female', 's', '1564434702319.jpg', 'qwqw', 'wqwq', '2019-07-29');

-- --------------------------------------------------------

--
-- Table structure for table `tblmainmenus`
--

CREATE TABLE `tblmainmenus` (
  `id` bigint(20) NOT NULL,
  `label` varchar(100) NOT NULL,
  `route` varchar(200) NOT NULL,
  `iconClasses` varchar(200) NOT NULL,
  `separator` tinyint(1) NOT NULL,
  `rank` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblmainmenus`
--

INSERT INTO `tblmainmenus` (`id`, `label`, `route`, `iconClasses`, `separator`, `rank`) VALUES
(1, 'Main Navigation', '', '', 1, '1'),
(2, 'Administrator', '', 'fa fa-user-secret', 0, '3'),
(3, 'Dashboard', '/', 'fa fa-dashboard', 0, '2'),
(4, 'Record Master', '', 'fa fa-th-large', 0, '4'),
(5, 'Students', '', 'fa fa-users', 0, '5');

-- --------------------------------------------------------

--
-- Table structure for table `tblprefixes`
--

CREATE TABLE `tblprefixes` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `prefix` varchar(15) NOT NULL,
  `startcount` int(15) NOT NULL,
  `created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblprefixes`
--

INSERT INTO `tblprefixes` (`id`, `name`, `prefix`, `startcount`, `created`) VALUES
(1, 'students', '2019-11-', 27, '0000-00-00'),
(2, 'bla', 'bla', 2, '2019-07-25');

-- --------------------------------------------------------

--
-- Table structure for table `tblschoolyears`
--

CREATE TABLE `tblschoolyears` (
  `id` int(15) NOT NULL,
  `sy` varchar(10) NOT NULL,
  `description` varchar(255) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblschoolyears`
--

INSERT INTO `tblschoolyears` (`id`, `sy`, `description`, `created`) VALUES
(1, '2018-2019', 'f', '2019-07-16 00:00:00'),
(3, '2019-2020', '', '2019-07-16 19:36:29'),
(4, '2020-2023', '', '2019-07-21 20:39:48');

-- --------------------------------------------------------

--
-- Table structure for table `tblsemesters`
--

CREATE TABLE `tblsemesters` (
  `id` int(15) NOT NULL,
  `semester` varchar(100) NOT NULL,
  `syid` int(15) NOT NULL,
  `description` varchar(200) NOT NULL,
  `created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsemesters`
--

INSERT INTO `tblsemesters` (`id`, `semester`, `syid`, `description`, `created`) VALUES
(1, 'ddd', 3, '', '2019-07-21'),
(2, 'fdas', 3, '', '2019-07-21'),
(3, 'kkk', 1, '', '2019-07-21');

-- --------------------------------------------------------

--
-- Table structure for table `tblspecializations`
--

CREATE TABLE `tblspecializations` (
  `id` int(11) NOT NULL,
  `specialization` varchar(100) NOT NULL,
  `courseid` int(15) NOT NULL,
  `description` varchar(200) NOT NULL,
  `created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblspecializations`
--

INSERT INTO `tblspecializations` (`id`, `specialization`, `courseid`, `description`, `created`) VALUES
(12, 'Major in Information Technology', 2, '', '2019-07-19'),
(13, 'Major in System Development', 2, '', '2019-07-19'),
(14, 'Major in Tindahan', 2, '', '2019-07-19'),
(15, 'Nursing', 1, '', '2019-07-19'),
(16, 'fds', 1, '', '2019-07-22');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubjects`
--

CREATE TABLE `tblsubjects` (
  `id` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `specializationid` int(11) NOT NULL,
  `description` varchar(200) NOT NULL,
  `created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsubjects`
--

INSERT INTO `tblsubjects` (`id`, `subject`, `specializationid`, `description`, `created`) VALUES
(1, 'fds', 15, '', '2019-07-22'),
(2, 'tre', 12, '', '2019-07-22'),
(3, 'rew', 16, '', '2019-07-22');

-- --------------------------------------------------------

--
-- Table structure for table `tblsubmenus`
--

CREATE TABLE `tblsubmenus` (
  `id` int(11) NOT NULL,
  `label` varchar(100) NOT NULL,
  `route` varchar(100) NOT NULL,
  `iconClasses` varchar(100) NOT NULL,
  `parent` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblsubmenus`
--

INSERT INTO `tblsubmenus` (`id`, `label`, `route`, `iconClasses`, `parent`) VALUES
(1, 'Users', 'administrator/users', 'fa fa-users', 2),
(3, 'School Year', 'rm/sy', 'fa fa-institution', 4),
(4, 'Semesters', 'rm/semesters', 'fa fa-list-alt', 4),
(6, 'Courses', 'rm/courses', 'fa fa-graduation-cap', 4),
(7, 'Specializations', 'rm/specializations', 'fa fa-user-md', 4),
(8, 'Subjects', 'rm/subjects', 'fa fa-book', 4),
(9, 'Information', 'students/information', 'fa fa-file', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(20) NOT NULL,
  `role` varchar(15) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `position` varchar(255) NOT NULL,
  `profile` varchar(100) NOT NULL,
  `active` int(11) NOT NULL,
  `created` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `email`, `password`, `role`, `firstname`, `lastname`, `position`, `profile`, `active`, `created`) VALUES
(1, 'n_oandasan@yahoo.com', '1', '', 'bong', 'Monforte', 'programmer', '1563224819042-1.jpg', 1, '2019-07-08 19:15:35'),
(2, 'n_oandasan1@yahoo.com', 'rrrrrrr', '', 'rrrr', 'rrrrrr', '', '', 1, '2019-07-08 19:18:53'),
(3, 'fda@gmail.com', 'fdfsfdsfs', '', 'dfdsfds', 'fdsfdsfdsfs', '', '', 1, '2019-07-08 19:28:49'),
(6, 'gfd@gmail.com', '4444444', '', '54', '55454', '', '', 1, '2019-07-09 00:37:37'),
(7, 'fdsaG.h@maila.com', 'fdafds', '', 'fds', 'fdsfs', '', '', 1, '2019-07-11 16:33:40'),
(8, 'dfd@smharabia.com', 'ds34343', '', '4343', '4343434343', '', '', 0, '2019-07-14 12:40:21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblcourses`
--
ALTER TABLE `tblcourses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `tblinformations`
--
ALTER TABLE `tblinformations`
  ADD PRIMARY KEY (`studentid`),
  ADD UNIQUE KEY `id` (`studentid`);

--
-- Indexes for table `tblmainmenus`
--
ALTER TABLE `tblmainmenus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `tblprefixes`
--
ALTER TABLE `tblprefixes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `tblschoolyears`
--
ALTER TABLE `tblschoolyears`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tblsemesters`
--
ALTER TABLE `tblsemesters`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `syid` (`syid`);

--
-- Indexes for table `tblspecializations`
--
ALTER TABLE `tblspecializations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `courseid` (`courseid`);

--
-- Indexes for table `tblsubjects`
--
ALTER TABLE `tblsubjects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `specializationid` (`specializationid`);

--
-- Indexes for table `tblsubmenus`
--
ALTER TABLE `tblsubmenus`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `id_2` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblcourses`
--
ALTER TABLE `tblcourses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblmainmenus`
--
ALTER TABLE `tblmainmenus`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblprefixes`
--
ALTER TABLE `tblprefixes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tblschoolyears`
--
ALTER TABLE `tblschoolyears`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblsemesters`
--
ALTER TABLE `tblsemesters`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblspecializations`
--
ALTER TABLE `tblspecializations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tblsubjects`
--
ALTER TABLE `tblsubjects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `tblsubmenus`
--
ALTER TABLE `tblsubmenus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
