module.exports = function(sequelize, DataTypes){
	const subjectoffers = sequelize.define('tblsubjectoffers', {
		subjectid: {
			type: DataTypes.INTEGER
		},
		levelid: {
			type: DataTypes.INTEGER
		},
		semesterid:{
			type: DataTypes.INTEGER
		},
		units: {
			type: DataTypes.INTEGER
		},
		subjectpre: {
			type: DataTypes.INTEGER
		},
		specializationid: {
			type: DataTypes.INTEGER
		},
		created: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: DataTypes.NOW
		}
	},{
			timestamps: false
	});
	return subjectoffers;
}
