module.exports = function(sequelize, DataTypes){
	const enrolledsubjects = sequelize.define('tblenrolledsubjects', {
		studentid: {
			type: DataTypes.INTEGER
		},
		subjectid: {
			type: DataTypes.INTEGER
		},
		enrolled: {
			type: DataTypes.INTEGER
		},
		schoolyearid: {
			type: DataTypes.INTEGER
		},
		levelid: {
			type: DataTypes.INTEGER
		},
		semesterid: {
			type: DataTypes.INTEGER
		},
		courseid: {
			type: DataTypes.INTEGER
		},
		specializationid: {
			type: DataTypes.INTEGER
		},
	},{
			timestamps: false
	});
	return enrolledsubjects;
}
