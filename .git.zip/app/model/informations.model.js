module.exports = function(sequelize, DataTypes){
	const prefixes = sequelize.define('tblinformations', {
		studentid: {
			type: DataTypes.STRING,
			primaryKey: true
		},
		firstname: {
			type: DataTypes.STRING
		},
		middlename: {
			type: DataTypes.STRING
		},
		lastname: {
			type: DataTypes.STRING
		},
		birthdate: {
			type: DataTypes.DATE
		},
		marital: {
			type: DataTypes.STRING
		},
		sex: {
			type: DataTypes.STRING
		},
		religion: {
			type: DataTypes.STRING
		},
		picture: {
			type: DataTypes.STRING
		},
		contactno: {
			type: DataTypes.STRING
		},
		email: {
			type: DataTypes.STRING
		},
		permanentaddress: {
			type: DataTypes.STRING
		},
		presentaddress: {
			type: DataTypes.STRING
		},
		highesteducation: {
			type: DataTypes.STRING
		},
		schoolastattended: {
			type: DataTypes.STRING
		},
		yearattended: {
			type: DataTypes.STRING
		},
		created: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: DataTypes.NOW
		}
	},{
			timestamps: false
	});
	return prefixes;
}
