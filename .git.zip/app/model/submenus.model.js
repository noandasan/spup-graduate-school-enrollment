module.exports = (sequelize, Sequelize) => {
	const SubMenus = sequelize.define('tblsubmenus', {
		label: {
			type: Sequelize.STRING
		},
		route: {
			type: Sequelize.STRING
		},
		iconClasses: {
			type: Sequelize.STRING
		},
		parent: {
			type: Sequelize.INTEGER
		}
	  }, {
			timestamps: false
		});
	return SubMenus;
}
