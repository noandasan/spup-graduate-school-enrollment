module.exports = function(sequelize, DataTypes){
	const levels = sequelize.define('tbllevels', {
		level: {
			type: DataTypes.STRING
		},
		description: {
			type: DataTypes.STRING
		},
		created: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: DataTypes.NOW
		}
	},{
			timestamps: false
	});
	return levels;
}
