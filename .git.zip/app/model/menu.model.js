module.exports = (sequelize, Sequelize) => {
	const Menus = sequelize.define('tblmainmenus', {
		label: {
			type: Sequelize.STRING
		},
		route: {
			type: Sequelize.STRING
		},
		iconClasses: {
			type: Sequelize.STRING
		},
		'separator': {
			type: Sequelize.STRING
		}
	  }, {
			timestamps: false
		});
	return Menus;
}
