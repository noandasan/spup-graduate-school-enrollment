module.exports = function(sequelize, DataTypes){
	const prefixes = sequelize.define('tblprefixes', {
		name: {
			type: DataTypes.STRING
		},
		prefix: {
			type: DataTypes.INTEGER
		},
		startcount: {
			type: DataTypes.INTEGER
		},
		created: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: DataTypes.NOW
		}
	},{
			timestamps: false
	});
	return prefixes;
}
