module.exports = function(sequelize, DataTypes){
	const addresses = sequelize.define('tbladdresses', {
		permanentadd: {
			type: DataTypes.STRING
		},
		currentaddress: {
			type: DataTypes.STRING
		},
		employeeid: {
			type: DataTypes.STRING
		},
		created: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: DataTypes.NOW
		}
	},{
			timestamps: false
	});
	return addresses;
}
