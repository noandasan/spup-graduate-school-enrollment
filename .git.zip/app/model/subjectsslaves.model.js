module.exports = function(sequelize, DataTypes){
	const subjectsslaves = sequelize.define('tblsubjectsslaves', {
		subject: {
			type: DataTypes.STRING
		},
		specializationid: {
			type: DataTypes.INTEGER
		},
		description: {
			type: DataTypes.STRING
		},
		created: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: DataTypes.NOW
		}
	},{
			timestamps: false
	});
	return subjectsslaves;
}
