module.exports = function(sequelize, DataTypes){
	const schoolyears = sequelize.define('tblschoolyears', {
		sy: {
			type: DataTypes.STRING
		},
		description: {
			type: DataTypes.STRING
		},
		active: {
			type: DataTypes.INTEGER
		},
		created: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: DataTypes.NOW
		}
	},{
			timestamps: false
	});
	return schoolyears;
}
