module.exports = function(sequelize, DataTypes){
	const semesters = sequelize.define('tblsemesters', {
		semester: {
			type: DataTypes.STRING
		},
		description: {
			type: DataTypes.STRING
		},
		active: {
			type: DataTypes.INTEGER
		},
		created: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: DataTypes.NOW
		}
	},{
			timestamps: false
	});
	return semesters;
}
