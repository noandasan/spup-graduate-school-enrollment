module.exports = function(sequelize, DataTypes){
	const courses = sequelize.define('tblcourses', {
		acourse: {
			type: DataTypes.STRING
		},
		course: {
			type: DataTypes.STRING
		},
		description: {
			type: DataTypes.STRING
		},
		created: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: DataTypes.NOW
		}
	},{
			timestamps: false
	});
	return courses;
}
