module.exports = function(sequelize, DataTypes){
	const enrollments = sequelize.define('tblenrollments', {
		studentid: {
			type: DataTypes.INTEGER
		},
		schoolyearid: {
			type: DataTypes.INTEGER
		},
		levelid: {
			type: DataTypes.INTEGER
		},
		semesterid: {
			type: DataTypes.INTEGER
		},
		courseid: {
			type: DataTypes.INTEGER
		},
		specializationid: {
			type: DataTypes.INTEGER
		},
		created: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: DataTypes.NOW
		}
	},{
			timestamps: false
	});
	return enrollments;
}
