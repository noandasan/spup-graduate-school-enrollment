module.exports = function(sequelize, DataTypes){
	const Users = sequelize.define('tblusers', {
		email: {
			type: DataTypes.STRING
		},
		password: {
			type: DataTypes.STRING
		},
		firstname: {
			type: DataTypes.STRING
		},
		lastname: {
			type: DataTypes.STRING
		},
		position: {
			type: DataTypes.STRING
		},
		profile: {
			type: DataTypes.STRING
		},
		active: {
			type: DataTypes.INTEGER
		},
		created: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: DataTypes.NOW
		}
	},{
			timestamps: false
	});
	return Users;
}
