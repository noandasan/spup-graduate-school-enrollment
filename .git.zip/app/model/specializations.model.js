module.exports = function(sequelize, DataTypes){
	const specializations = sequelize.define('tblspecializations', {
		specialization: {
			type: DataTypes.STRING
		},
		courseid: {
			type: DataTypes.INTEGER
		},
		description: {
			type: DataTypes.STRING
		},
		created: {
			type: DataTypes.DATE,
			allowNull: false,
			defaultValue: DataTypes.NOW
		}
	},{
			timestamps: false
	});
	return specializations;
}
