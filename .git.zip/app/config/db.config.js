const env = require('./env.js');

const Sequelize = require('sequelize');
const sequelize = new Sequelize(env.database, env.username, env.password, {
  host: env.host,
  dialect: env.dialect,
  operatorsAliases: false,

  pool: {
    max: env.max,
    min: env.pool.min,
    acquire: env.pool.acquire,
    idle: env.pool.idle
  }
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;




db.menus = require('../model/menu.model.js')(sequelize, Sequelize);
db.submenus = require('../model/submenus.model.js')(sequelize, Sequelize);
db.users = require('../model/user.model.js')(sequelize, Sequelize);
db.sy = require('../model/sy.model.js')(sequelize, Sequelize);
db.courses = require('../model/courses.model.js')(sequelize, Sequelize);
db.specializations = require('../model/specializations.model.js')(sequelize, Sequelize);
db.semesters = require('../model/semesters.model.js')(sequelize, Sequelize);
db.subjects = require('../model/subjects.model.js')(sequelize, Sequelize);
db.subjectsslaves = require('../model/subjectsslaves.model.js')(sequelize, Sequelize);
db.prefix = require('../model/prefix.model.js')(sequelize, Sequelize);
db.informations = require('../model/informations.model.js')(sequelize, Sequelize);
db.addresses = require('../model/addresses.model.js')(sequelize, Sequelize);
db.levels = require('../model/levels.model.js')(sequelize, Sequelize);
db.subjectoffers = require('../model/subjectoffers.model.js')(sequelize, Sequelize);
db.enrollments = require('../model/enrollments.model.js')(sequelize, Sequelize);
db.enrolledsubjects = require('../model/enrolledsubjects.model.js')(sequelize, Sequelize);

module.exports = db;