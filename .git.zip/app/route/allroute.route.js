module.exports = function(app) {
    const Users = require('../controller/user.controller.js');
    app.get('/api/getUsers', Users.getUsers);
    app.post('/api/AddUsers', Users.AddUsers);
    app.get('/api/getUserId/UserId/:UserId', Users.getUserId);
    app.post('/api/UpdateUser', Users.UpdateUser);
    app.post('/api/EnabledisableUser/UserId/:UserId/State/:State', Users.EnabledisableUser);
    app.post('/api/SearchUsers', Users.SearchUsers);
    app.get('/api/DeleteUser/UserId/:UserId', Users.DeleteUser);
    app.post('/api/Login', Users.Login);
    app.get('/api/MyProfile/userId/:UserId', Users.MyProfile);
    app.post('/api/ChangePass', Users.ChangePass);
    app.post('/api/UploadProfile/userId/:userId', Users.UploadProfile);
    
    //Menu    
    const Menu = require('../controller/menu.controller.js');
    app.get('/api/menu', Menu.Menu);

    const SY = require('../controller/sy.controller.js');
    app.get('/api/getSY', SY.getSY);
    app.get('/api/getSY1', SY.getSY1);

    app.post('/api/AddSY', SY.AddSY);
    app.post('/api/SearchSY', SY.SearchSY);
    app.get('/api/getSYId/SYId/:SYId', SY.getSYId);
    app.post('/api/UpdateSY', SY.UpdateSY);
    app.post('/api/EnabledisableSY/id/:id/State/:State', SY.EnabledisableSY);
    app.get('/api/DeleteSY/SYId/:SYId', SY.DeleteSY);

    //courses
    const Courses = require('../controller/courses.controller.js');
    app.get('/api/getCourses', Courses.getCourses);
    app.post('/api/AddCourses', Courses.AddCourses);
    app.post('/api/SearchCourses', Courses.SearchCourses);
    app.get('/api/getCoursesId/CoursesId/:CoursesId', Courses.getCoursesId);
    app.post('/api/UpdateCourses', Courses.UpdateCourses);
    //app.post('/api/EnabledisableUser/UserId/:UserId/State/:State', SY.EnabledisableUser);
    app.get('/api/DeleteCourses/CoursesId/:CoursesId', Courses.DeleteCourses);
    
     //specialization
     const Specializations = require('../controller/specializations.controller.js');
     app.get('/api/getSpecializations', Specializations.getSpecializations);
     app.post('/api/AddSpecializations', Specializations.AddSpecializations);
     app.post('/api/SearchSpecializations', Specializations.SearchSpecializations);
     app.get('/api/getSpecializationsId/SpecializationsId/:SpecializationsId', Specializations.getSpecializationsId);
     app.post('/api/UpdateSpecializations', Specializations.UpdateSpecializations);
     //app.post('/api/EnabledisableUser/UserId/:UserId/State/:State', SY.EnabledisableUser);
     app.get('/api/DeleteSpecializations/SpecializationsId/:SpecializationsId', Specializations.DeleteSpecializations);
     
     app.get('/api/GetSpecializationsIdSubject/SpecializationsId/:SpecializationsId', Specializations.GetSpecializationsIdSubject);
     
     

       //Semesters
       const Semesters = require('../controller/semesters.controller.js');
       app.get('/api/getSemesters', Semesters.getSemesters);
       app.get('/api/getSemesters1', Semesters.getSemesters1);
       app.post('/api/AddSemesters', Semesters.AddSemesters);
       app.post('/api/SearchSemesters', Semesters.SearchSemesters);
       app.get('/api/getSemestersId/SemestersId/:SemestersId', Semesters.getSemestersId);
       app.post('/api/UpdateSemesters', Semesters.UpdateSemesters);
       app.post('/api/EnabledisableSemester/id/:id/State/:State', Semesters.EnabledisableSemester);
       app.get('/api/DeleteSemesters/SemestersId/:SemestersId', Semesters.DeleteSemesters);
 
        //Subjects
        const Subjects = require('../controller/subjects.controller.js');
        app.get('/api/getSubjects', Subjects.getSubjects);

        app.post('/api/AddSubjects', Subjects.AddSubjects);
        app.post('/api/SearchSubjects', Subjects.SearchSubjects);
        app.get('/api/GetSubjectsId/SubjectsId/:SubjectsId', Subjects.getSubjectsId);
        app.post('/api/UpdateSubjects', Subjects.UpdateSubjects);
        //app.post('/api/EnabledisableUser/UserId/:UserId/State/:State', SY.EnabledisableUser);
        app.get('/api/DeleteSubjects/SubjectsId/:SemestersId', Subjects.DeleteSubjects);

        const Prefix = require('../controller/prefix.controller.js');
        app.get('/api/getPrefix', Prefix.getPrefix);
        // app.post('/api/AddSubjects', Subjects.AddSubjects);
        // app.post('/api/SearchSubjects', Subjects.SearchSubjects);
        // app.get('/api/GetSubjectsId/SubjectsId/:SubjectsId', Subjects.getSubjectsId);
        // app.post('/api/UpdateSubjects', Subjects.UpdateSubjects);
        // //app.post('/api/EnabledisableUser/UserId/:UserId/State/:State', SY.EnabledisableUser);
        // app.get('/api/DeleteSubjects/SubjectsId/:SemestersId', Subjects.DeleteSubjects);


        const Informations = require('../controller/informations.controller.js');
        app.get('/api/getInformations', Informations.getInformations);
        app.post('/api/UploadProfile', Informations.UploadProfile);
        app.post('/api/AddInformations', Informations.AddInformations);
        app.post('/api/SearchInformations', Informations.SearchInformations);
        app.get('/api/GetInformationsId/InformationsId/:InformationsId', Informations.getInformationsId);
        app.post('/api/UpdateInformations', Informations.UpdateInformations);
        // //app.post('/api/EnabledisableUser/UserId/:UserId/State/:State', SY.EnabledisableUser);
        // app.get('/api/DeleteSubjects/SubjectsId/:SemestersId', Subjects.DeleteSubjects);

        const Levels = require('../controller/levels.controller.js');
        app.get('/api/getLevels', Levels.getLevels);
         app.post('/api/AddLevels', Levels.AddLevels);
         app.post('/api/SearchLevels', Levels.SearchLevels);
         app.get('/api/getLevelsId/LevelsId/:LevelsId', Levels.getLevelsId);
         app.post('/api/UpdateLevels', Levels.UpdateLevels);
        // // app.post('/api/EnabledisableUser/UserId/:UserId/State/:State', SY.EnabledisableUser);
          app.get('/api/DeleteLevels/LevelsId/:LevelsId', Levels.DeleteLevels);
        

          const SubjectOffers = require('../controller/subjectoffers.controller.js');
          app.post('/api/AddSubjectoffers', SubjectOffers.AddSubjectoffers);
          app.get('/api/loadSubjectOffer/SpecializationsId/:SpecializationsId', SubjectOffers.loadSubjectOffer);

          
          //  app.post('/api/AddLevels', Levels.AddLevels);
          //  app.post('/api/SearchLevels', Levels.SearchLevels);
          //  app.get('/api/getLevelsId/LevelsId/:LevelsId', Levels.getLevelsId);
          //  app.post('/api/UpdateLevels', Levels.UpdateLevels);
          // // // app.post('/api/EnabledisableUser/UserId/:UserId/State/:State', SY.EnabledisableUser);
          //   app.get('/api/DeleteLevels/LevelsId/:LevelsId', Levels.DeleteLevels);
          
          const Enrollment = require('../controller/enrollments.controller.js');
          app.get('/api/getEnrollment', Enrollment.getEnrollment);
          app.post('/api/addNewEnrollment', Enrollment.addNewEnrollment);
          
          app.get('/api/EnrollmentCourse/courseid/:courseid', Enrollment.EnrollmentCourse);
          app.post('/api/EnrollmentSubject', Enrollment.EnrollmentSubject);
          app.post('/api/EnrollmentSubjectAvialable', Enrollment.EnrollmentSubjectAvialable);
          app.post('/api/SearchEnrollment', Enrollment.SearchEnrollment);
          
          app.get('/api/getEnrollmentId/enrollmentid/:enrollmentid', Enrollment.getEnrollmentId);
          app.post('/api/EnrollSubject/id/:id/enrolled/:enrolled/courseid/:courseid/levelid/:levelid/schoolyearid/:schoolyearid/semesterid/:semesterid/specializationid/:specializationid/studentid/:studentid', Enrollment.EnrollSubject);
          app.post('/api/UpdateEnrollment', Enrollment.UpdateEnrollment);
          
}











































 // app.get('/api/deleteEducation/EducationId/:EducationId',  education.deleteEducation);