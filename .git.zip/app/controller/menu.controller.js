const db = require('../config/db.config.js');
const Menu = db.menus;
const Submenus = db.submenus;

const jwt = require('jsonwebtoken')
process.env.SECRET_KEY = 'secret'
// Post a users
const Sequelize = require('sequelize');

exports.Menu = (req, res) => {
  Menu.hasMany(Submenus, { foreignKey: 'parent', targetKey: 'id' });
  Menu.findAll({
    include:
      [{
        model: Submenus,
        required: false,
        attributes: ['id','label', 'route', 'iconClasses', 'parent'],
        order: [
          ['id', 'ASC']
        ]
      }],
    order: [
      ['rank', 'ASC']
    ],
    attributes: ['id', 'label', 'route', 'iconClasses', 'separator'],
  }).then(menu => {
    let data = [];
    let child = [];

    for (var i = 0; i < menu.length; i++) {
      if (menu[i].tblsubmenus.length != 0) {
        child = [];
        for (var x = 0; x < menu[i].tblsubmenus.length; x++) {
         
          menu[i].tblsubmenus.sort(function(a, b){
            return a.id - b.id;
          });

          if (menu[i].tblsubmenus[x].parent == menu[i].id) {
            child.push({ label: menu[i].tblsubmenus[x].label, route: menu[i].tblsubmenus[x].route, iconClasses: menu[i].tblsubmenus[x].iconClasses });
          }
        }
     
        data.push({ label: menu[i].label, iconClasses: menu[i].iconClasses, children: child });
      } else {
        data.push({ label: menu[i].label, route: menu[i].route, iconClasses: menu[i].iconClasses, separator: menu[i].separator });
      }
    }
    res.json(data);
  });
};
