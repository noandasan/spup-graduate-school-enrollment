const env = require('../config/env.js');
const db = require('../config/db.config.js');
const _Subjectoffers = db.subjectoffers;
const _Subjects = db.subjects;
const _Semesters = db.semesters;
const _Subjectsslaves= db.subjectsslaves;
const _Levels = db.levels;


const Sequelize = require('sequelize');
const Op = Sequelize.Op;
var path = require('path');



        // subjectpre: req.body.subjectpre,
        // semesterid: req.body.semesterid,
        // specializationid: req.body.specializationid
        


exports.AddSubjectoffers = (req, res, next) => {
  console.log(req.body);
  try {
    const subjectData={
      subjectid: req.body.subjectid,
      specializationid: req.body.specializationid,
      semesterid: req.body.semesterid,
      units: req.body.units,
      subjectpre: req.body.subjectpre
    }
    _Subjectoffers.count({
     attributes: ['id'],
     where: {
       subjectid: req.body.subjectid,
       specializationid: req.body.specializationid,
     }
   })
    .then(result => {
      if (!result || result=='0') {
        _Subjectoffers.create(subjectData)
        .then(result => {
          _Subjectoffers.belongsTo(_Subjects,{ foreignKey: 'subjectid', targetKey: 'id' })
          _Subjectoffers.belongsTo(_Levels,{ foreignKey: 'levelid', targetKey: 'id' })
          _Subjectoffers.belongsTo(_Semesters,{ foreignKey: 'semesterid', targetKey: 'id' })
          _Subjectoffers.belongsTo(_Subjectsslaves, {foreignKey: 'subjectpre', targetKey: 'id' })
          _Subjectoffers.findAll({
            include:
            [
              {
              model: _Subjects,
              required: false,
              attributes: ['id','subject'],
            },{
              model: _Semesters,
              required: false,
              attributes: ['id','semester'],
            },{
              model: _Subjectsslaves,
              required: false,
              attributes: ['id','subject'],
            },{
              model: _Levels,
              required: false,
              attributes: ['id','level'],
            }
          ],
              attributes: ['units'],
              order: [
                ['id', 'DESC']
              ],
              where: { 
               specializationid: req.body.specializationid
              } 
            }).then(result => {
           
              res.json({result});
            })
          })
      } else {
        res.json({ error: true })
      }
    })
  }
  catch (err) {
    return next(err);
  }
 };

 exports.loadSubjectOffer=(req, res, next)=>{
  
  _Subjectoffers.belongsTo(_Subjects,{ foreignKey: 'subjectid', targetKey: 'id' })
  _Subjectoffers.belongsTo(_Levels,{ foreignKey: 'levelid', targetKey: 'id' })
  _Subjectoffers.belongsTo(_Semesters,{ foreignKey: 'semesterid', targetKey: 'id' })
  _Subjectoffers.belongsTo(_Subjectsslaves, {foreignKey: 'subjectpre', targetKey: 'id' })
  _Subjectoffers.findAll({
    include:
    [
      {
      model: _Subjects,
      required: false,
      attributes: ['id','subject'],
    },{
      model: _Semesters,
      required: false,
      attributes: ['id','semester'],
    },{
      model: _Subjectsslaves,
      required: false,
      attributes: ['id','subject'],
    },{
      model: _Levels,
      required: false,
      attributes: ['id','level'],
    },
  ],
      attributes: ['units'],
      order: [
        ['id', 'DESC']
      ],
       where: { 
        specializationid: req.params.SpecializationsId
       } 
      
    }).then(result => {
      console.log(result);
      res.json({result});
    })
 }