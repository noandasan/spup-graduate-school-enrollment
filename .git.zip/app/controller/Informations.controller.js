const env = require('../config/env.js');
const db = require('../config/db.config.js');
const _Informations = db.informations;
const _Prefix = db.prefix;

const Sequelize = require('sequelize');
const Op = Sequelize.Op;
var path = require('path');
var multer = require('multer');


//get course
exports.getInformations = (req, res) => {
  try {
    _Informations.findAll({
        attributes: ['studentid','firstname','lastname','picture'],
        order: [
          ['studentid', 'DESC']
        ]
      })
        .then(result => {
          res.json({result});
        })
    }
    catch (err) {
      return next(err);
    }
  };

  //upload image
var store = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './app/public/profiles');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now()+''+ file.originalname);
  }
});
var upload = multer({ storage: store }).single('file');

exports.UploadProfile = (req, res, next) => {
  upload(req, res, function (err) {
    if (err) {
      return res.status(501).json({ error: err });
    }
    try {
          res.json(req.file.filename);  
    }
    catch (err) {
      return next(err);
    }
  });
}

exports.AddInformations = (req, res, next) => {
try {
_Prefix.findOne({
  where: {
    name: 'students'
  }
}).then(result=>{
  let prefix=result.prefix;
  let startcount=result.startcount;
  let completecount=parseInt(startcount)+1;

  let id=prefix+''+completecount;

  const InformationData = {
    studentid: id,
    firstname: req.body.firstname,
    middlename: req.body.middlename,
    lastname: req.body.lastname,
    birthdate: req.body.birthdate,
    marital: req.body.marital,
    sex: req.body.sex,
    religion: req.body.religion,
    picture: req.body.picture,
    contactno: req.body.contactno,
    email: req.body.email,
    permanentaddress: req.body.permanentaddress,
    presentaddress: req.body.presentaddress,
    highesteducation:  req.body.highesteducation,
    schoolastattended:  req.body.schoolastattended,
    yearattended:  req.body.yearattended

  }
  _Informations.findOne({
    where: {
      studentid:id
    }
  })
    .then(result => {
      if (!result) {
        
        _Informations.create(InformationData)
          .then(result => {
            res.json({ result })
            _Prefix.update(
              {
                startcount:completecount
              },
              { where: { name: 'students' } }
            )
          }) 
          .catch(err => {
            res.send('error: ' + err)
          })
      } else {
        res.json({ error: true })
      }
    })
    .catch(err => {
      res.send('error: ' + err)
    })
  })
  }
  catch (err) {
    return next(err);
  }
};

exports.SearchInformations = (req, res) => {
  const InformationsData = {
    searchkey: req.body.searchkey,
    searchfield: req.body.searchfield
  }

  var field = InformationsData.searchfield;
  var field = field.trim().toLowerCase();
  var whereStatement = {};
console.log(field);
  if (field === "student id") {
    whereStatement.studentid = { [Op.like]: '%' + InformationsData.searchkey + '%' };
  }
  if (field === "first name") {
    whereStatement.firstname = { [Op.like]: '%' + InformationsData.searchkey + '%' };
  }
  if (field === "last name") {
    whereStatement.lastname = { [Op.like]: '%' + InformationsData.searchkey + '%' };
  }
  if (field === "created") {
    whereStatement.created = { [Op.between]: InformationsData.searchkey };
  }

  try {
 
    _Informations.findAll({ 
      attributes: ['studentid','firstname','lastname','picture'],
      order: [
        ['studentid', 'DESC']
      ],
      where: whereStatement
    })
      .then(result => {
        res.json({result});
      })
   }
  catch (err) {
    return next(err);
  }
};

exports.getInformationsId = (req, res) => {
  try {
    _Informations.findOne({
      where: {
        studentid: req.params.InformationsId
      }
  })
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

exports.UpdateInformations = (req, res, next) => {
  try {
    _Informations.update(
    {
      firstname: req.body.firstname,
      middlename: req.body.middlename,
      lastname: req.body.lastname,
      birthdate: req.body.birthdate,
      marital: req.body.marital,
      sex: req.body.sex,
      religion: req.body.religion,
      picture: req.body.picture,
      contactno: req.body.contactno,
      email: req.body.email,
      permanentaddress: req.body.permanentaddress,
      presentaddress: req.body.presentaddress,
      highesteducation:  req.body.highesteducation,
      schoolastattended:  req.body.schoolastattended,
      yearattended:  req.body.yearattended
    },
    { where: { studentid: req.body.studentid } }
  )
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}