const env = require('../config/env.js');
const db = require('../config/db.config.js');
const _Users = db.users;


var multer = require('multer');
var express = require('express');
var AES = require("crypto-js/aes");
var SHA256 = require("crypto-js/sha256");
var CryptoJS = require("crypto-js");



const jwt = require('jsonwebtoken')
process.env.SECRET_KEY = 'secret'


// Post a users
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
var path = require('path');



exports.Login = (req, res, next) => {
  console.log("dsa");
  try {
      _Users.findOne({
        where: {
          email: req.body.email,
          password: req.body.password,
          active: 1
        },
        attributes: ['id', 'email', 'role']
      })
        .then(user => {
          if (user) {
            let token = jwt.sign(user.dataValues, process.env.SECRET_KEY, {
              expiresIn: 1440
            })
            res.json({ token: token })
          } else {
            res.json({ error: true })
          }
        })
        .catch(err => {
          res.send('error: ' + err)
        })
    }
    catch (err) {
      return next(err);
    }
}

//get Users
exports.getUsers = (req, res) => {
  try {
      _Users.findAll({
        order: [
          ['id', 'DESC']
        ]
      })
        .then(Users => {
          res.json({Users});
        })
    }
    catch (err) {
      return next(err);
    }
  };
  //add user
  exports.AddUsers = (req, res) => {
    try {
      
    const userData = {
      email: req.body.email,
      password: req.body.password,
      firstname: req.body.firstname,
      lastname: req.body.lastname
    }
    _Users.findOne({
      where: {
        email: req.body.email
      }
    })
      .then(User => {
        if (!User) {
          _Users.create(userData)
            .then(User => {
              let token = jwt.sign(User.dataValues, process.env.SECRET_KEY, {
                expiresIn: 1440
              })
              res.json({ token: token })
            })
            .catch(err => {
              res.send('error: ' + err)
            })
        } else {
          res.json({ error: true })
        }
      })
      .catch(err => {
        res.send('error: ' + err)
      })
    }
    catch (err) {
      return next(err);
    }
  };

  //GetID
exports.getUserId = (req, res) => {
  try {
  _Users.findOne({
    where: {
      id: req.params.UserId
    }
  })
    .then(User => {
      res.json({User});
    })
  }
  catch (err) {
    return next(err);
  }
}
//Update User
exports.UpdateUser = (req, res) => {
  try {
  _Users.update(
    {
      email: req.body.email,
      password: req.body.password,
      firstname: req.body.firstname,
      lastname: req.body.lastname,
      position: req.body.position
    },
    { where: { id: req.body.id } }
  )
    .then(Users => {
      res.json({Users});
    })
  }
  catch (err) {
    return next(err);
  }
}

exports.EnabledisableUser = (req, res, next) => {
  try {
    _Users.update(
      {
        active: req.params.State
      },
      {
        where:
          { id: req.params.UserId }
      }
    )
      .then(result => {
        res.json({result});
      })
  }
  catch (err) {
    return next(err);
  }
}

//Search Users
exports.SearchUsers = (req, res) => {
  const userData = {
    searchkey: req.body.searchkey,
    searchfield: req.body.searchfield
  }

  var field = userData.searchfield;
  var field = field.trim().toLowerCase();
  var whereStatement = {};

  if (field === "email") {
    whereStatement.email = { [Op.like]: '%' + userData.searchkey + '%' };
  }
  if (field === "firstname") {
    whereStatement.firstname = { [Op.like]: '%' + userData.searchkey + '%' };
  }
  if (field === "lastname") {
    whereStatement.lastname = { [Op.like]: '%' + userData.searchkey + '%' };
  }
  if (field === "created") {
    whereStatement.created = { [Op.between]: userData.searchkey };
  }

  try {
    _Users.findAll({
      order: [
        ['id', 'DESC']
      ],
      where: whereStatement
    })
      .then(Users => {

        res.json({Users});
      })
   }
  catch (err) {
    return next(err);
  }
};

//Delete User
exports.DeleteUser = (req, res, next) => {
  try {
  _Users.destroy({
    where: {
      id: req.params.UserId
    }
  })
    .then(Users => {
      res.json({Users});
    })
  }
  catch (err) {
    return next(err);
  }
}
//get my profile
exports.MyProfile = (req, res) => {
  try {
  _Users.findOne({
    attributes: ['email', 'lastname', 'firstname','profile','position'],
    where: {
      id: req.params.UserId
    }
  })
    .then(User => {
      res.json({User});
    })
  }
  catch (err) {
    return next(err);
  }
}

//get my profile
exports.ChangePass = (req, res, next) => {
  try {
    _Users.findOne({
      where: {
        id: req.body.id,
        password: req.body.currentpassword
      },
      attributes:['id']
    }).then(result => {
      console.log(result);
        if (result) {
          _Users.update(
            {
              password: req.body.password
            },
            { where: { id: req.body.id } }
          )
          res.json({error: false})
        } else {
          res.json({ error: true })
        }
      })
  }
  catch (err) {
    return next(err);
  }
}


//upload image
var store = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, './app/public/profiles');
  },
  filename: function (req, file, cb) {
    cb(null, Date.now() + '-' + file.originalname);
  }
});
var upload = multer({ storage: store }).single('file');

exports.UploadProfile = (req, res, next) => {
  upload(req, res, function (err) {
    if (err) {
      return res.status(501).json({ error: err });
    }
    try {
      _Users.update(
        {
          profile: req.file.filename
        },
        { where: { id: req.params.userId } }
      )
        .then(User => {
          res.json(req.file.filename);
        })
    }
    catch (err) {
      return next(err);
    }
  });
}