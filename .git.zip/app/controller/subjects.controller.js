const env = require('../config/env.js');
const db = require('../config/db.config.js');
const _Subjects = db.subjects;
const _Specializations = db.specializations;

const Sequelize = require('sequelize');
const Op = Sequelize.Op;
var path = require('path');



//get course
exports.getSubjects = (req, res) => {
  try {
    _Subjects.belongsTo(_Specializations,{ foreignKey: 'specializationid', targetKey: 'id' })
    _Subjects.findAll({
      include:
      [{
        model: _Specializations,
        required: false,
        attributes: ['id','specialization'],
      }],
        attributes: ['id','subject'],
        order: [
          ['id', 'DESC']
        ]
      })
        .then(result => {
          
          res.json({result});
        })
    }
    catch (err) {
      return next(err);
    }
  };

  exports.getSubjectsPre = (req, res) => {
    try {
      _Subjects.belongsTo(_Specializations,{ foreignKey: 'specializationid', targetKey: 'id' })
      _Subjects.findAll({
        include:
        [{
          model: _Specializations,
          required: false,
          attributes: ['id','specialization'],
        }],
          attributes: ['id','subject'],
          order: [
            ['id', 'DESC']
          ]
        })
          .then(result => {
            console.log(result);
            res.json(result);
          })
      }
      catch (err) {
        return next(err);
      }
    };

  exports.AddSubjects = (req, res) => {
    console.log(req.body);
    try {
    const SubjectsData = {
      subject: req.body.subject,
      specializationid: req.body.specializationid
    }
    _Subjects.findOne({
      where: {
        subject: req.body.subject
      }
    })
      .then(result => {
        if (!result) {
          console.log('fds');
          _Subjects.create(SubjectsData)
            .then(result => {
              res.json({ result })
            })
            .catch(err => {
              res.send('error: ' + err)
            })
        } else {
          console.log('fds');
          res.json({ error: true })
        }
      })
      .catch(err => {
        res.send('error: ' + err)
      })
    }
    catch (err) {
      console.log('fds');
      return next(err);
    }
  };

  exports.SearchSubjects = (req, res) => {
    _Subjects.belongsTo(_Specializations,{foreignKey: 'specializationid', targetKey: 'id' })
    const SubjectsData = {
      searchkey: req.body.searchkey,
      searchfield: req.body.searchfield
    }
  
    var field = SubjectsData.searchfield;
    var field = field.trim().toLowerCase();
    var whereStatement = {};
    var whereStatement1 = {};
  
    if (field === "subject") {
      whereStatement.subject = { [Op.like]: '%' + SubjectsData.searchkey + '%' };
    }
    if (field === "specialization") {
     
      whereStatement1.specialization = { [Op.like]: '%' + SubjectsData.searchkey + '%' };
    }
    if (field === "created") {
      whereStatement.created = { [Op.between]: SubjectsData.searchkey };
    }

    try {
   
      _Subjects.findAll({
          include:
          [{
            model: _Specializations,
            required: true,
            attributes: ['id','specialization'],
            where: whereStatement1
          }],
        attributes: ['id','subject'],
        where: whereStatement
      })
        .then(result => {
  
          res.json({result});
        })
     }
    catch (err) {
      return next(err);
    }
  };

//    //GetID
exports.getSubjectsId = (req, res) => {
  try {
    _Subjects.findOne({
      attributes: ['id','subject','specializationid'],
      where: {
        id: req.params.SubjectsId
      }
  })
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

// // //Update User
exports.UpdateSubjects = (req, res, next) => {
  try {
    _Subjects.update(
    {
      specializationid: req.body.specializationid,
      subject: req.body.subject
    },
    { where: { id: req.body.id } }
  )
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

// //Delete User
exports.DeleteSubjects = (req, res, next) => {
  try {
    _Subjects.destroy({
    where: {
      id: req.params.SubjectsId
    }
  })
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}