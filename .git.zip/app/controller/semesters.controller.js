const env = require('../config/env.js');
const db = require('../config/db.config.js');
const _Semesters = db.semesters;
const _Sy = db.sy;

const Sequelize = require('sequelize');
const Op = Sequelize.Op;
var path = require('path');



//get course
exports.getSemesters = (req, res) => {
  try {
    _Semesters.findAll({
        order: [
          ['id', 'DESC']
        ]
      })
        .then(result => {
          res.json({result});
        })
    }
    catch (err) {
      return next(err);
    }
  };

  exports.getSemesters1 = (req, res) => {
    try {
      _Semesters.findAll({
          order: [
            ['id', 'DESC']
          ],
          where: {
            active: 1
          }
        })
          .then(result => {
            res.json({result});
          })
      }
      catch (err) {
        return next(err);
      }
    };


  exports.AddSemesters = (req, res) => {
    try {
    const SemestersData = {
      semester: req.body.semester
    }
    _Semesters.findOne({
      where: {
        semester: req.body.semester
      }
    })
      .then(result => {
        if (!result) {
          _Semesters.create(SemestersData)
            .then(result => {
              res.json({ result })
            })
            .catch(err => {
              res.send('error: ' + err)
            })
        } else {
          res.json({ error: true })
        }
      })
      .catch(err => {
        res.send('error: ' + err)
      })
    }
    catch (err) {
      return next(err);
    }
  };

  exports.SearchSemesters = (req, res) => {
    const SemestersData = {
      searchkey: req.body.searchkey,
      searchfield: req.body.searchfield
    }
  
    var field = SemestersData.searchfield;
    var field = field.trim().toLowerCase();
    var whereStatement = {};
    var whereStatement1 = {};
  
    if (field === "semester") {
      whereStatement.semester = { [Op.like]: '%' + SemestersData.searchkey + '%' };
    }
    if (field === "created") {
      whereStatement.created = { [Op.between]: CoursesData.searchkey };
    }

    try {
   
      _Semesters.findAll({
        attributes: ['id','semester'],
        where: whereStatement
      })
        .then(result => {
  
          res.json({result});
        })
     }
    catch (err) {
      return next(err);
    }
  };

//    //GetID
exports.getSemestersId = (req, res) => {
  try {
    _Semesters.findOne({
      attributes: ['id','semester','syid'],
      where: {
        id: req.params.SemestersId
      }
  })
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

// // //Update User
exports.UpdateSemesters = (req, res, next) => {
  try {
      _Semesters.update(
    {
      semester: req.body.semester
    },
    { where: { id: req.body.id } }
  )
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

// //Delete User
exports.DeleteSemesters = (req, res, next) => {
  try {
    _Semesters.destroy({
    where: {
      id: req.params.SemestersId
    }
  })
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

exports.EnabledisableSemester = (req, res, next) => {
  try {
    _Semesters.update(
      {
        active: req.params.State
      },
      {
        where:
          { id: req.params.id }
      }
    )
      .then(result => {
        res.json({result});
      })
  }
  catch (err) {
    return next(err);
  }
}