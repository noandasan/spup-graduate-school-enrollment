const env = require('../config/env.js');
const db = require('../config/db.config.js');
const _Courses = db.courses;

const Sequelize = require('sequelize');
const Op = Sequelize.Op;
var path = require('path');



//get course
exports.getCourses = (req, res) => {
  try {
    _Courses.findAll({
        order: [
          ['id', 'DESC']
        ]
      })
        .then(result => {
          res.json({result});
        })
    }
    catch (err) {
      return next(err);
    }
  };

  exports.AddCourses = (req, res) => {
    try {
    const CoursesData = {
      acourse: req.body.acourse,
      course: req.body.course
    }
    _Courses.findOne({
      where: {
        acourse: req.body.acourse
      }
    })
      .then(result => {
        if (!result) {
          _Courses.create(CoursesData)
            .then(result => {
              res.json({ result })
            })
            .catch(err => {
              res.send('error: ' + err)
            })
        } else {
          res.json({ error: true })
        }
      })
      .catch(err => {
        res.send('error: ' + err)
      })
    }
    catch (err) {
      return next(err);
    }
  };

  exports.SearchCourses = (req, res) => {
    const CoursesData = {
      searchkey: req.body.searchkey,
      searchfield: req.body.searchfield
    }
  
    var field = CoursesData.searchfield;
    var field = field.trim().toLowerCase();
    var whereStatement = {};
  
    if (field === "course abbv") {
      whereStatement.acourse = { [Op.like]: '%' + CoursesData.searchkey + '%' };
    }
    if (field === "course") {
      whereStatement.course = { [Op.like]: '%' + CoursesData.searchkey + '%' };
    }
    if (field === "created") {
      whereStatement.created = { [Op.between]: CoursesData.searchkey };
    }
  
    try {
      _Courses.findAll({
        order: [
          ['id', 'DESC']
        ],
        where: whereStatement
      })
        .then(result => {
  
          res.json({result});
        })
     }
    catch (err) {
      return next(err);
    }
  };
   //GetID
exports.getCoursesId = (req, res) => {
  try {
    _Courses.findOne({
    where: {
      id: req.params.CoursesId
    }
  })
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

// //Update User
exports.UpdateCourses = (req, res, next) => {
  try {
    var acourse = req.body.acourse;
    var acourse = acourse.toUpperCase();
    _Courses.update(
    {
      acourse: acourse,
      course: req.body.course
    },
    { where: { id: req.body.id } }
  )
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

// //Delete User
exports.DeleteCourses = (req, res, next) => {
  try {
    _Courses.destroy({
    where: {
      id: req.params.CoursesId
    }
  })
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}