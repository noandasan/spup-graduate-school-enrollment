const env = require('../config/env.js');
const db = require('../config/db.config.js');
const _Specializations = db.specializations;
const _Courses = db.courses;
const _Subjects = db.subjects;

const Sequelize = require('sequelize');
const Op = Sequelize.Op;
var path = require('path');



//get course
exports.getSpecializations = (req, res) => {
  try {
    _Specializations.belongsTo(_Courses,{ foreignKey: 'courseid', targetKey: 'id' })
    _Specializations.findAll({
      include:
      [{
        model: _Courses,
        required: false,
        attributes: ['id','acourse','course'],
      }],
        attributes: ['id','specialization'],
        order: [
          ['id', 'DESC']
        ]
      })
        .then(result => {
          
          res.json({result});
        })
    }
    catch (err) {
      return next(err);
    }
  };

  exports.AddSpecializations = (req, res) => {
    
    try {
    const SpecializationsData = {
      courseid: req.body.courseId,
      specialization: req.body.specialization
    }
    _Specializations.findOne({
      where: {
        specialization: req.body.specialization
      }
    })
      .then(result => {
        if (!result) {
          _Specializations.create(SpecializationsData)
            .then(result => {
              res.json({ result })
            })
            .catch(err => {
              res.send('error: ' + err)
            })
        } else {
          res.json({ error: true })
        }
      })
      .catch(err => {
        res.send('error: ' + err)
      })
    }
    catch (err) {
      return next(err);
    }
  };

  exports.SearchSpecializations = (req, res) => {
    _Specializations.belongsTo(_Courses,{foreignKey: 'courseid', targetKey: 'id' })
    const SpecializationsData = {
      searchkey: req.body.searchkey,
      searchfield: req.body.searchfield
    }
  
    var field = SpecializationsData.searchfield;
    var field = field.trim().toLowerCase();
    var whereStatement = {};
    var whereStatement1 = {};
  
    if (field === "specialization") {
      whereStatement.specialization = { [Op.like]: '%' + SpecializationsData.searchkey + '%' };
    }
    if (field === "course abbv") {
     
      whereStatement1.acourse = { [Op.like]: '%' + SpecializationsData.searchkey + '%' };
    }
    if (field === "course") {
      whereStatement1.course = { [Op.like]: '%' + SpecializationsData.searchkey + '%' };
    }
    if (field === "created") {
      whereStatement.created = { [Op.between]: SpecializationsData.searchkey };
    }

    try {
   
    _Specializations.findAll({
          include:
          [{
            model: _Courses,
            required: true,
            attributes: ['id','acourse','course'],
            where: whereStatement1
          }],
        attributes: ['id','specialization'],
        where: whereStatement
      })
        .then(result => {
  
          res.json({result});
        })
     }
    catch (err) {
      return next(err);
    }
  };
   //GetID
exports.getSpecializationsId = (req, res) => {
  try {
    _Specializations.findOne({
      attributes: ['id','specialization','courseid'],
      where: {
        id: req.params.SpecializationsId
      }
  })
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

// //Update User
exports.UpdateSpecializations = (req, res, next) => {
  try {
  
    _Specializations.update(
    {
      courseid: req.body.courseId,
      specialization: req.body.specialization
    },
    { where: { id: req.body.id } }
  )
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

// //Delete User
exports.DeleteSpecializations = (req, res, next) => {
  try {
    _Specializations.destroy({
    where: {
      id: req.params.SpecializationsId
    }
  })
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

exports.GetSpecializationsIdSubject = (req, res, next) => {
  try {
       _Subjects.findAll({
        attributes: ['id','subject'],
        where: {
          specializationid: req.params.SpecializationsId
        }
      })
        .then(result => {
            res.json({result});
        })
     }
    catch (err) {
      return next(err);
    }
}