const env = require('../config/env.js');
const db = require('../config/db.config.js');
const _Prefixes = db.prefix;

const Sequelize = require('sequelize');
const Op = Sequelize.Op;
var path = require('path');



//get course
exports.getPrefix = (req, res) => {
  try {
    _Prefixes.findAll({
        order: [
          ['id', 'DESC']
        ]
      })
        .then(result => {
          res.json({result});
        })
    }
    catch (err) {
      return next(err);
    }
  };

  