const env = require('../config/env.js');
const db = require('../config/db.config.js');
const _Levels = db.levels;


const jwt = require('jsonwebtoken')
process.env.SECRET_KEY = 'secret'


// Post a users
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
var path = require('path');



//get Users
exports.getLevels = (req, res) => {
  try {
    _Levels.findAll({
        order: [
          ['id', 'DESC']
        ]
      })
        .then(result => {
          res.json({result});
        })
    }
    catch (err) {
      return next(err);
    }
  };
//AddNew
  exports.AddLevels = (req, res) => {
    try {
    const LevelsData = {
      level: req.body.level
    }
    _Levels.findOne({
      where: {
        level: req.body.level
      }
    })
      .then(result => {
        if (!result) {
            _Levels.create(LevelsData)
            .then(result => {
              res.json({ result })
            })
            .catch(err => {
              res.send('error: ' + err)
            })
        } else {
          res.json({ error: true })
        }
      })
      .catch(err => {
        res.send('error: ' + err)
      })
    }
    catch (err) {
      return next(err);
    }
  };

  exports.getLevelsId = (req, res) => {
    try {
        _Levels.findOne({
      where: {
        id: req.params.LevelsId
      }
    })
      .then(result => {
        res.json({result});
      })
    }
    catch (err) {
      return next(err);
    }
  }
  
  //Update User
  exports.UpdateLevels = (req, res, next) => {
    try {
        _Levels.update(
      {
        level: req.body.level
      },
      { where: { id: req.body.id } }
    )
      .then(result => {
        res.json({result});
      })
    }
    catch (err) {
      return next(err);
    }
  }

  exports.DeleteLevels = (req, res, next) => {
    try {
        _Levels.destroy({
      where: {
        id: req.params.LevelsId
      }
    })
      .then(result => {
        res.json({result});
      })
    }
    catch (err) {
      return next(err);
    }
  }

  exports.SearchLevels = (req, res) => {
    const LevelsData = {
      searchkey: req.body.searchkey,
      searchfield: req.body.searchfield
    }
  
    var field = LevelsData.searchfield;
    var field = field.trim().toLowerCase();
    var whereStatement = {};
  
    if (field === "level") {
      whereStatement.level = { [Op.like]: '%' + LevelsData.searchkey + '%' };
    }
    if (field === "created") {
      whereStatement.created = { [Op.between]: LevelsData.searchkey };
    }
  
    try {
        _Levels.findAll({
        order: [
          ['id', 'DESC']
        ],
        where: whereStatement
      })
        .then(result => {
  
          res.json({result});
        })
     }
    catch (err) {
      return next(err);
    }
  };