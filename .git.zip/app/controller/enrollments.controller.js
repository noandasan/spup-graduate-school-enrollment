const env = require('../config/env.js');
const db = require('../config/db.config.js');
const _Enrollments = db.enrollments;
const _Informations = db.informations;
const _Semesters = db.semesters;
const _Subjectsslaves= db.subjectsslaves;
const _Levels = db.levels;
const _Subjectoffers = db.subjectoffers;
const _Subjects = db.subjects;
const _SchoolYears = db.sy;
const _Courses = db.courses;
const _Enrolledsubjects = db.enrolledsubjects;

const _Specializations = db.specializations;

const Sequelize = require('sequelize');
const Op = Sequelize.Op;
var path = require('path');

exports.SearchEnrollment = (req, res) => {
  _Enrollments.belongsTo(_Informations,{ foreignKey: 'studentid', targetKey: 'studentid' })
  _Enrollments.belongsTo(_SchoolYears,{ foreignKey: 'schoolyearid', targetKey: 'id' })
  _Enrollments.belongsTo(_Levels,{ foreignKey: 'levelid', targetKey: 'id' })
  _Enrollments.belongsTo(_Semesters,{ foreignKey: 'semesterid', targetKey: 'id' })
  _Enrollments.belongsTo(_Courses,{ foreignKey: 'courseid', targetKey: 'id' })
  _Enrollments.belongsTo(_Specializations,{ foreignKey: 'specializationid', targetKey: 'id' })
  
  const EnrollData = {
    searchkey: req.body.searchkey,
    searchfield: req.body.searchfield
  }

  var field = EnrollData.searchfield;
  var field = field.trim().toLowerCase();
  var whereStatement = {};
  var whereStatement1 = {};
  var whereStatement2 = {};
  var whereStatement3 = {};
  var whereStatement4 = {};
  var whereStatement5 = {};
  var whereStatement6 = {};

  if (field === "studentid") {
    whereStatement.studentid = { [Op.like]: '%' + EnrollData.searchkey + '%' };
  }
  if (field === "firstname") {
   
    whereStatement1.firstname = { [Op.like]: '%' + EnrollData.searchkey + '%' };
  }
  if (field === "lastname") {
    whereStatement1.lastname = { [Op.like]: '%' + EnrollData.searchkey + '%' };
  }
   if (field === "middlename") {
     whereStatement1.middlename = { [Op.like]: '%' + EnrollData.searchkey + '%' };
   }
   if (field === "sy") {
    whereStatement2.sy = { [Op.like]: '%' + EnrollData.searchkey + '%' };
  }
  if (field === "level") {
    whereStatement3.level = { [Op.like]: '%' + EnrollData.searchkey + '%' };
  }
  if (field === "semester") {
    whereStatement4.semester = { [Op.like]: '%' + EnrollData.searchkey + '%' };
  }
  if (field === "course") {
    whereStatement5.course = { [Op.like]: '%' + EnrollData.searchkey + '%' };
  }
  if (field === "specialization") {
    whereStatement6.specialization = { [Op.like]: '%' + EnrollData.searchkey + '%' };
  }

  _Enrollments.findAll({
    include:
    [{
      model: _Informations,
      required: true,
      attributes: ['firstname','middlename', 'lastname'],
      where: whereStatement1
    },{
      model: _SchoolYears,
      required: true,
      attributes: ['id','sy'],
      where: whereStatement2
    },{
      model: _Levels,
      required: true,
      attributes: ['id','level'],
      where: whereStatement3
    },{
      model: _Semesters,
      required: true,
      attributes: ['id','semester'],
      where: whereStatement4
    },{
      model: _Courses,
      required: true,
      attributes: ['id','course'],
      where: whereStatement5
    },{
      model: _Specializations,
      required: true,
      attributes: ['id','specialization'],
      where: whereStatement6
    }],
      attributes:['studentid'],
      order: [
        ['id', 'DESC']
      ],
      where: whereStatement 
    }).then(result => {
      res.json({result});
    })
 
  
};

exports.getEnrollment = (req, res, next) => {
  _Enrollments.belongsTo(_Informations,{ foreignKey: 'studentid', targetKey: 'studentid' })
  _Enrollments.belongsTo(_SchoolYears,{ foreignKey: 'schoolyearid', targetKey: 'id' })
  _Enrollments.belongsTo(_Levels,{ foreignKey: 'levelid', targetKey: 'id' })
  _Enrollments.belongsTo(_Semesters,{ foreignKey: 'semesterid', targetKey: 'id' })
  _Enrollments.belongsTo(_Courses,{ foreignKey: 'courseid', targetKey: 'id' })
  _Enrollments.belongsTo(_Specializations,{ foreignKey: 'specializationid', targetKey: 'id' })
  
  _Enrollments.findAll({
    include:
    [{
      model: _Informations,
      required: false,
      attributes: ['studentid','firstname','middlename', 'lastname'],
    },{
      model: _SchoolYears,
      required: false,
      attributes: ['id','sy'],
    },{
      model: _Levels,
      required: false,
      attributes: ['id','level'],
    },{
      model: _Semesters,
      required: false,
      attributes: ['id','semester'],
    },{
      model: _Courses,
      required: false,
      attributes: ['id','course'],
    },{
      model: _Specializations,
      required: false,
      attributes: ['id','specialization'],
    }
  ],
      order: [
        ['id', 'DESC']
      ],
    }).then(result => {
      res.json({result});
    })
 };


 exports.addNewEnrollment = (req, res, next) => {
    const EnrollData = {
      studentid: req.body.studentid,
      schoolyearid: req.body.schoolyearid,
      levelid: req.body.levelid,
      semesterid: req.body.semesterid,
      courseid: req.body.courseid,
      specializationid: req.body.specializationid
    }

    _Enrollments.count({
      order: [
        ['id', 'DESC']
      ],
      where: {
        studentid: req.body.studentid,
        schoolyearid: req.body.schoolyearid,
        levelid: req.body.levelid,
        semesterid: req.body.semesterid,
        courseid: req.body.courseid,
        specializationid: req.body.specializationid
      }
    }).then(result => {
      if (!result || result=='0') {
        _Enrollments.create(EnrollData)
         .then(result => {         
            res.json({ result })
          })
      } else {
        res.json({ error: true })
      }
    })
 };


 exports.EnrollmentCourse = (req, res, next) => {
   
  _Specializations.findAll({
    attributes:['id','specialization'],
    order: [
      ['id', 'DESC']
    ],
    where: {
      courseid: req.params.courseid
    }
    }).then(result => {
      res.json({result});
    })
 };

 exports.EnrollmentSubject = (req, res, next) => {
   _Subjectoffers.belongsTo(_Subjects,{ foreignKey: 'subjectid', targetKey: 'id' })
   _Subjectoffers.findAll({
    include:
    [
      {
      model: _Subjects,
      required: false,
      attributes: ['id','subject'],
    }],
    order: [
      ['id', 'DESC']
    ],
    where: {
      specializationid: req.body.specializationid
    }
    }).then(result => {
      const a=JSON.stringify(result);
      const b=JSON.parse(a);
       for(i=0; i<b.length;i++){
          _Enrolledsubjects.create({specializationid:req.body.specializationid,courseid:req.body.courseid,levelid:req.body.levelid,semesterid:req.body.semesterid, schoolyearid:req.body.schoolyearid, studentid:req.body.studentid, subjectid: b[i].tblsubject.id })
        }
         res.json({result});
    })
 };

 exports.getEnrollmentId = (req, res) => {
  try {
    _Enrollments.findOne({
    where: {
      id: req.params.enrollmentid
    }
  })
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

exports.EnrollmentSubjectAvialable = (req, res) => {
  _Enrolledsubjects.belongsTo(_Subjects,{ foreignKey: 'subjectid', targetKey: 'id' })
  _Enrolledsubjects.findAll({
    include:
    [
      {
      model: _Subjects,
      required: false,
      attributes: ['id','subject'],
    }],
    order: [
      ['id', 'DESC']
    ],
    where: {
      studentid: req.body.result.studentid,
      schoolyearid: req.body.result.schoolyearid,
      levelid: req.body.result.levelid,
      semesterid: req.body.result.semesterid,
      courseid: req.body.result.courseid,
      specializationid: req.body.result.specializationid
    }
  }).then(result => {
    res.json({result});
  })
}

exports.EnrollSubject = (req, res, next) => {
  try {
    _Enrolledsubjects.update(
      {
        enrolled: req.params.enrolled
      },
      {
        where:
          { id: req.params.id }
      }
    )
      .then(result => {
        _Enrolledsubjects.belongsTo(_Subjects,{ foreignKey: 'subjectid', targetKey: 'id' })
        _Enrolledsubjects.findAll({
          include:
          [
            {
            model: _Subjects,
            required: false,
            attributes: ['id','subject'],
          }],
          order: [
            ['id', 'DESC']
          ],
          where: {
            studentid: req.params.studentid,
            schoolyearid: req.params.schoolyearid,
            levelid: req.params.levelid,
            semesterid: req.params.semesterid,
            courseid: req.params.courseid,
            specializationid: req.params.specializationid
          }
        }).then(result => {
          res.json({result});
        })
          
      })
  }
  catch (err) {
    return next(err);
  }
}


exports.UpdateEnrollment = (req, res, next) => {
  try {
    _Enrollments.update(
    {
    studentid: req.body.studentid,
    schoolyearid: req.body.schoolyearid,
    levelid: req.body.levelid,
    semesterid: req.body.semesterid,
    courseid: req.body.courseid,
    specializationid: req.body.specializationid
    },
    { where: { id: req.body.id } }
  )
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}