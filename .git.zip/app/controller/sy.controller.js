const env = require('../config/env.js');
const db = require('../config/db.config.js');
const _SchoolYears = db.sy;


const jwt = require('jsonwebtoken')
process.env.SECRET_KEY = 'secret'


// Post a users
const Sequelize = require('sequelize');
const Op = Sequelize.Op;
var path = require('path');



//get Users
exports.getSY = (req, res) => {
  try {
    _SchoolYears.findAll({
        order: [
          ['id', 'DESC']
        ]
      })
        .then(result => {
          res.json({result});
        })
    }
    catch (err) {
      return next(err);
    }
  };

  exports.getSY1 = (req, res) => {
    try {
      _SchoolYears.findAll({
          order: [
            ['id', 'DESC']
          ],
          where: {
            active: 1
          }
        })
          .then(result => {
            res.json({result});
          })
      }
      catch (err) {
        return next(err);
      }
    };


  exports.AddSY = (req, res) => {
    try {
    const SYData = {
      sy: req.body.schoolyear
    }
    _SchoolYears.findOne({
      where: {
        sy: req.body.schoolyear
      }
    })
      .then(result => {
        if (!result) {
          _SchoolYears.create(SYData)
            .then(result => {
              res.json({ result })
            })
            .catch(err => {
              res.send('error: ' + err)
            })
        } else {
          res.json({ error: true })
        }
      })
      .catch(err => {
        res.send('error: ' + err)
      })
    }
    catch (err) {
      return next(err);
    }
  };

  exports.SearchSY = (req, res) => {
    const SYData = {
      searchkey: req.body.searchkey,
      searchfield: req.body.searchfield
    }
  
    var field = SYData.searchfield;
    var field = field.trim().toLowerCase();
    var whereStatement = {};
  
    if (field === "school year") {
      whereStatement.sy = { [Op.like]: '%' + SYData.searchkey + '%' };
    }
    if (field === "created") {
      whereStatement.created = { [Op.between]: SYData.searchkey };
    }
  
    try {
      _SchoolYears.findAll({
        order: [
          ['id', 'DESC']
        ],
        where: whereStatement
      })
        .then(result => {
  
          res.json({result});
        })
     }
    catch (err) {
      return next(err);
    }
  };
   //GetID
exports.getSYId = (req, res) => {
  try {
    _SchoolYears.findOne({
    where: {
      id: req.params.SYId
    }
  })
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

//Update User
exports.UpdateSY = (req, res, next) => {
  try {
    _SchoolYears.update(
    {
      sy: req.body.schoolyear
    },
    { where: { id: req.body.id } }
  )
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

//Delete User
exports.DeleteSY = (req, res, next) => {
  try {
    _SchoolYears.destroy({
    where: {
      id: req.params.SYId
    }
  })
    .then(result => {
      res.json({result});
    })
  }
  catch (err) {
    return next(err);
  }
}

exports.EnabledisableSY = (req, res, next) => {
  try {
    _SchoolYears.update(
      {
        active: req.params.State
      },
      {
        where:
          { id: req.params.id }
      }
    )
      .then(result => {
        res.json({result});
      })
  }
  catch (err) {
    return next(err);
  }
}